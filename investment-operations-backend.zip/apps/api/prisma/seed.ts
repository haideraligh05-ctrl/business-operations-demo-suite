import "dotenv/config";
import { randomBytes } from "node:crypto";
import bcrypt from "bcryptjs";
import { PrismaClient } from "../src/generated/prisma/index.js";

const prisma = new PrismaClient();

async function main() {
  if (process.env.NODE_ENV === "production") throw new Error("Local demo seed only");
  const adminSecret = randomBytes(24).toString("hex");
  const investorSecret = randomBytes(24).toString("hex");
  const adminPassword = await bcrypt.hash(adminSecret, 12);
  const investorPassword = await bcrypt.hash(investorSecret, 12);

  const admin = await prisma.user.upsert({
    where: { email: "admin@example.test" },
    update: { passwordHash: adminPassword },
    create: {
      email: "admin@example.test",
      passwordHash: adminPassword,
      firstName: "Demo",
      lastName: "Admin",
      role: "ADMIN",
      emailVerifiedAt: new Date(),
      wallet: { create: {} }
    }
  });

  const investor = await prisma.user.upsert({
    where: { email: "investor@example.test" },
    update: { passwordHash: investorPassword },
    create: {
      email: "investor@example.test",
      passwordHash: investorPassword,
      firstName: "Sample",
      lastName: "Investor",
      phone: "+10000000000",
      emailVerifiedAt: new Date(),
      wallet: { create: { balance: 250000 } },
      kycRecord: {
        create: {
          documentType: "National ID",
          documentNumber: "DEMO-ID-01",
          kraPin: "DEMO-TAX-ID",
          residentialAddress: "Sample City",
          bankName: "Sample Bank",
          bankAccountName: "Sample Investor",
          bankAccountNumber: "0000000000",
          status: "APPROVED",
          submittedAt: new Date(),
          reviewedAt: new Date(),
          reviewedById: admin.id
        }
      }
    }
  });

  const products = [
    {
      title: "Sample Infrastructure Bond",
      category: "BONDS" as const,
      description: "Government infrastructure bond with semi-annual coupon profile.",
      minimumAmount: 50000,
      expectedReturn: "13.5% p.a.",
      riskRating: "Low",
      tenure: "36 months",
      maturityDate: new Date("2029-06-30")
    },
    {
      title: "Sample Fixed Income Fund",
      category: "FUNDS" as const,
      description: "Diversified fixed-income strategy focused on capital preservation.",
      minimumAmount: 25000,
      expectedReturn: "10% - 12% p.a.",
      riskRating: "Medium",
      tenure: "12 months",
      maturityDate: new Date("2027-06-30")
    },
    {
      title: "Sample Equity Allocation",
      category: "NSE_STOCKS" as const,
      description: "Admin-managed NSE equity allocation for MVP portfolio tracking.",
      minimumAmount: 10000,
      expectedReturn: "Market-linked",
      riskRating: "High",
      tenure: "Open-ended",
      maturityDate: new Date("2030-12-31")
    },
    {
      title: "US Blue Chip NYSE Basket",
      category: "NYSE_STOCKS" as const,
      description: "Manual exposure to selected NYSE large-cap equities.",
      minimumAmount: 100000,
      expectedReturn: "Market-linked",
      riskRating: "High",
      tenure: "Open-ended",
      maturityDate: new Date("2030-12-31")
    }
  ];

  for (const product of products) {
    await prisma.investment.upsert({
      where: { id: `00000000-0000-4000-8000-${String(products.indexOf(product) + 1).padStart(12, "0")}` },
      update: product,
      create: {
        id: `00000000-0000-4000-8000-${String(products.indexOf(product) + 1).padStart(12, "0")}`,
        ...product,
        status: "ACTIVE"
      }
    });
  }

  const wallet = await prisma.wallet.findUnique({ where: { userId: investor.id } });
  if (wallet) {
    await prisma.walletTransaction.create({
      data: {
        walletId: wallet.id,
        type: "FUNDING",
        direction: "CREDIT",
        amount: 250000,
        balanceAfter: 250000,
        description: "Seed wallet opening balance"
      }
    });
  }

  await prisma.auditLog.create({
    data: {
      actorId: admin.id,
      action: "ADMIN_ACTION",
      entityType: "Seed",
      metadata: { message: "Seed data installed" }
    }
  });

  console.log("Seed complete");
  console.log(`admin@example.test / ${adminSecret}`);
  console.log(`investor@example.test / ${investorSecret}`);
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
