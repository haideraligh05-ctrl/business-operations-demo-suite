import { Router } from "express";
import { z } from "zod";
import { UserRole } from "../generated/prisma/index.js";
import { prisma } from "../config/prisma.js";
import { requireAuth, requireRole } from "../common/auth.js";
import { AppError, asyncHandler, ok, validate } from "../common/http.js";
import { audit } from "../common/audit.js";
import { storePrivateFile, upload } from "../common/upload.js";

const router = Router();

const kycSchema = z.object({
  documentType: z.string().min(1),
  documentNumber: z.string().min(1),
  kraPin: z.string().min(1),
  residentialAddress: z.string().min(1),
  bankName: z.string().min(1),
  bankAccountName: z.string().min(1),
  bankAccountNumber: z.string().min(1)
});

router.get("/me", requireAuth, asyncHandler(async (req, res) => {
  const record = await prisma.kycRecord.findUnique({ where: { userId: req.user!.id }, include: { documents: true } });
  ok(res, record);
}));

router.put("/me", requireAuth, asyncHandler(async (req, res) => {
  const input = validate(kycSchema, req.body);
  const record = await prisma.kycRecord.upsert({
    where: { userId: req.user!.id },
    create: { userId: req.user!.id, ...input },
    update: { ...input, status: "DRAFT", rejectionReason: null }
  });
  ok(res, record);
}));

router.post("/me/documents", requireAuth, upload.single("file"), asyncHandler(async (req, res) => {
  if (!req.file) throw new AppError(422, "File is required");
  const { type } = validate(z.object({ type: z.string().min(1) }), req.body);
  const kyc = await prisma.kycRecord.upsert({ where: { userId: req.user!.id }, create: { userId: req.user!.id }, update: {} });
  const file = await storePrivateFile(req.file, `kyc/${req.user!.id}`);
  const doc = await prisma.kycDocument.create({ data: { kycRecordId: kyc.id, type, ...file } });
  ok(res, doc);
}));

router.post("/me/submit", requireAuth, asyncHandler(async (req, res) => {
  const record = await prisma.kycRecord.findUnique({ where: { userId: req.user!.id }, include: { documents: true } });
  if (!record) throw new AppError(404, "KYC record not found");
  if (!record.documentNumber || !record.kraPin || !record.residentialAddress || record.documents.length < 3) {
    throw new AppError(422, "Complete KYC details and upload required documents before submission");
  }
  const updated = await prisma.kycRecord.update({
    where: { id: record.id },
    data: { status: "SUBMITTED", submittedAt: new Date(), rejectionReason: null }
  });
  await audit(req, { action: "KYC_SUBMITTED", entityType: "KycRecord", entityId: updated.id });
  ok(res, updated);
}));

router.get("/admin", requireAuth, requireRole(UserRole.ADMIN), asyncHandler(async (_req, res) => {
  const records = await prisma.kycRecord.findMany({ include: { user: true, documents: true }, orderBy: { updatedAt: "desc" } });
  ok(res, records);
}));

router.post("/admin/:id/approve", requireAuth, requireRole(UserRole.ADMIN), asyncHandler(async (req, res) => {
  const record = await prisma.kycRecord.update({
    where: { id: req.params.id },
    data: { status: "APPROVED", reviewedAt: new Date(), reviewedById: req.user!.id, rejectionReason: null }
  });
  await audit(req, { action: "KYC_APPROVED", entityType: "KycRecord", entityId: record.id });
  ok(res, record);
}));

router.post("/admin/:id/reject", requireAuth, requireRole(UserRole.ADMIN), asyncHandler(async (req, res) => {
  const { reason } = validate(z.object({ reason: z.string().min(1) }), req.body);
  const record = await prisma.kycRecord.update({
    where: { id: req.params.id },
    data: { status: "REJECTED", reviewedAt: new Date(), reviewedById: req.user!.id, rejectionReason: reason }
  });
  await audit(req, { action: "KYC_REJECTED", entityType: "KycRecord", entityId: record.id, metadata: { reason } });
  ok(res, record);
}));

export default router;
