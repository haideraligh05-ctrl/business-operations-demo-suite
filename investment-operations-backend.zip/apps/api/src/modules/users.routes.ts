import { Router } from "express";
import { z } from "zod";
import { UserRole } from "../generated/prisma/index.js";
import { prisma } from "../config/prisma.js";
import { requireAuth, requireRole } from "../common/auth.js";
import { asyncHandler, ok, validate } from "../common/http.js";
import { audit } from "../common/audit.js";

const router = Router();

router.get("/admin/users", requireAuth, requireRole(UserRole.ADMIN), asyncHandler(async (req, res) => {
  const q = typeof req.query.q === "string" ? req.query.q : undefined;
  const users = await prisma.user.findMany({
    where: {
      deletedAt: null,
      ...(q ? { OR: [{ email: { contains: q, mode: "insensitive" } }, { firstName: { contains: q, mode: "insensitive" } }, { lastName: { contains: q, mode: "insensitive" } }] } : {})
    },
    include: { wallet: true, kycRecord: true },
    orderBy: { createdAt: "desc" }
  });
  ok(res, users);
}));

router.get("/admin/users/:id", requireAuth, requireRole(UserRole.ADMIN), asyncHandler(async (req, res) => {
  const user = await prisma.user.findUnique({
    where: { id: req.params.id },
    include: { wallet: { include: { transactions: true } }, kycRecord: { include: { documents: true } }, portfolioHoldings: { include: { investment: true } } }
  });
  ok(res, user);
}));

router.patch("/admin/users/:id/status", requireAuth, requireRole(UserRole.ADMIN), asyncHandler(async (req, res) => {
  const { status } = validate(z.object({ status: z.enum(["ACTIVE", "INACTIVE", "SUSPENDED"]) }), req.body);
  const user = await prisma.user.update({ where: { id: req.params.id }, data: { status } });
  await audit(req, { action: "ADMIN_ACTION", entityType: "User", entityId: user.id, metadata: { status } });
  ok(res, user);
}));

export default router;
