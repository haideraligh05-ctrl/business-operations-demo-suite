import { Router } from "express";
import { z } from "zod";
import { UserRole } from "../generated/prisma/index.js";
import { prisma } from "../config/prisma.js";
import { requireAuth, requireRole } from "../common/auth.js";
import { AppError, asyncHandler, ok, validate } from "../common/http.js";

const router = Router();

router.get("/me", requireAuth, asyncHandler(async (req, res) => {
  const holdings = await prisma.portfolioHolding.findMany({
    where: { userId: req.user!.id },
    include: { investment: true, returnUpdates: { orderBy: { createdAt: "desc" }, take: 5 } },
    orderBy: { createdAt: "desc" }
  });
  ok(res, holdings);
}));

router.patch("/admin/holdings/:id/returns", requireAuth, requireRole(UserRole.ADMIN), asyncHandler(async (req, res) => {
  const input = validate(z.object({
    expectedReturnAmount: z.coerce.number().nonnegative(),
    currentValue: z.coerce.number().nonnegative(),
    note: z.string().optional()
  }), req.body);

  const holding = await prisma.portfolioHolding.findUnique({ where: { id: req.params.id } });
  if (!holding) throw new AppError(404, "Portfolio holding not found");

  const result = await prisma.$transaction(async (tx) => {
    await tx.portfolioReturnUpdate.create({
      data: {
        portfolioHoldingId: holding.id,
        expectedReturnAmount: input.expectedReturnAmount,
        currentValue: input.currentValue,
        note: input.note
      }
    });
    return tx.portfolioHolding.update({
      where: { id: holding.id },
      data: {
        expectedReturnAmount: input.expectedReturnAmount,
        currentValue: input.currentValue
      }
    });
  });
  ok(res, result);
}));

export default router;
