import { Router } from "express";
import { z } from "zod";
import { InvestmentCategory, UserRole } from "../generated/prisma/index.js";
import { prisma } from "../config/prisma.js";
import { requireAuth, requireRole } from "../common/auth.js";
import { AppError, asyncHandler, created, ok, validate } from "../common/http.js";
import { audit } from "../common/audit.js";
import { decimal } from "../common/money.js";

const router = Router();

const investmentSchema = z.object({
  title: z.string().min(1),
  category: z.nativeEnum(InvestmentCategory),
  description: z.string().min(1),
  minimumAmount: z.coerce.number().positive(),
  expectedReturn: z.string().min(1),
  riskRating: z.string().min(1),
  tenure: z.string().min(1),
  maturityDate: z.coerce.date(),
  status: z.enum(["DRAFT", "ACTIVE", "ARCHIVED", "MATURED"]).default("ACTIVE")
});

router.get("/", requireAuth, asyncHandler(async (_req, res) => {
  const investments = await prisma.investment.findMany({
    where: { status: "ACTIVE", deletedAt: null },
    orderBy: { createdAt: "desc" }
  });
  ok(res, investments);
}));

router.get("/admin", requireAuth, requireRole(UserRole.ADMIN), asyncHandler(async (_req, res) => {
  const investments = await prisma.investment.findMany({ where: { deletedAt: null }, orderBy: { createdAt: "desc" } });
  ok(res, investments);
}));

router.post("/admin", requireAuth, requireRole(UserRole.ADMIN), asyncHandler(async (req, res) => {
  const input = validate(investmentSchema, req.body);
  const investment = await prisma.investment.create({ data: input });
  await audit(req, { action: "INVESTMENT_CREATED", entityType: "Investment", entityId: investment.id });
  created(res, investment);
}));

router.patch("/admin/:id", requireAuth, requireRole(UserRole.ADMIN), asyncHandler(async (req, res) => {
  const input = validate(investmentSchema.partial(), req.body);
  const investment = await prisma.investment.update({ where: { id: req.params.id }, data: input });
  await audit(req, { action: "INVESTMENT_UPDATED", entityType: "Investment", entityId: investment.id });
  ok(res, investment);
}));

router.delete("/admin/:id", requireAuth, requireRole(UserRole.ADMIN), asyncHandler(async (req, res) => {
  const investment = await prisma.investment.update({ where: { id: req.params.id }, data: { status: "ARCHIVED", deletedAt: new Date() } });
  ok(res, investment);
}));

router.post("/requests", requireAuth, asyncHandler(async (req, res) => {
  const { investmentId, amount } = validate(z.object({ investmentId: z.string().uuid(), amount: z.coerce.number().positive() }), req.body);
  const investment = await prisma.investment.findFirst({ where: { id: investmentId, status: "ACTIVE", deletedAt: null } });
  if (!investment) throw new AppError(404, "Investment not found");
  if (decimal(amount).lessThan(investment.minimumAmount)) throw new AppError(422, "Amount is below the minimum investment");

  const wallet = await prisma.wallet.findUnique({ where: { userId: req.user!.id } });
  if (!wallet || decimal(wallet.balance).lessThan(amount)) throw new AppError(422, "Insufficient wallet balance");

  const request = await prisma.investmentRequest.create({ data: { userId: req.user!.id, investmentId, amount } });
  await audit(req, { action: "INVESTMENT_REQUESTED", entityType: "InvestmentRequest", entityId: request.id, metadata: { amount } });
  created(res, request);
}));

router.get("/requests/me", requireAuth, asyncHandler(async (req, res) => {
  const requests = await prisma.investmentRequest.findMany({
    where: { userId: req.user!.id },
    include: { investment: true },
    orderBy: { createdAt: "desc" }
  });
  ok(res, requests);
}));

router.get("/admin/requests", requireAuth, requireRole(UserRole.ADMIN), asyncHandler(async (_req, res) => {
  const requests = await prisma.investmentRequest.findMany({
    include: { user: true, investment: true },
    orderBy: { createdAt: "desc" }
  });
  ok(res, requests);
}));

router.post("/admin/requests/:id/approve", requireAuth, requireRole(UserRole.ADMIN), asyncHandler(async (req, res) => {
  const result = await prisma.$transaction(async (tx) => {
    const investmentRequest = await tx.investmentRequest.findUnique({
      where: { id: req.params.id },
      include: { investment: true }
    });
    if (!investmentRequest || investmentRequest.status !== "PENDING") throw new AppError(422, "Investment request cannot be approved");

    const wallet = await tx.wallet.findUnique({ where: { userId: investmentRequest.userId } });
    if (!wallet || decimal(wallet.balance).lessThan(investmentRequest.amount)) throw new AppError(422, "Insufficient wallet balance");

    const balanceAfter = decimal(wallet.balance).minus(investmentRequest.amount);
    await tx.wallet.update({ where: { id: wallet.id }, data: { balance: balanceAfter } });
    await tx.walletTransaction.create({
      data: {
        walletId: wallet.id,
        type: "INVESTMENT",
        direction: "DEBIT",
        amount: investmentRequest.amount,
        balanceAfter,
        reference: investmentRequest.id,
        description: `Investment approved: ${investmentRequest.investment.title}`
      }
    });
    const approved = await tx.investmentRequest.update({
      where: { id: investmentRequest.id },
      data: { status: "APPROVED", reviewedAt: new Date(), reviewedById: req.user!.id }
    });
    await tx.portfolioHolding.create({
      data: {
        userId: investmentRequest.userId,
        investmentId: investmentRequest.investmentId,
        investmentRequestId: investmentRequest.id,
        principalAmount: investmentRequest.amount,
        currentValue: investmentRequest.amount,
        maturityDate: investmentRequest.investment.maturityDate
      }
    });
    return approved;
  });
  await audit(req, { action: "INVESTMENT_APPROVED", entityType: "InvestmentRequest", entityId: result.id });
  ok(res, result);
}));

router.post("/admin/requests/:id/reject", requireAuth, requireRole(UserRole.ADMIN), asyncHandler(async (req, res) => {
  const { reason } = validate(z.object({ reason: z.string().min(1) }), req.body);
  const result = await prisma.investmentRequest.update({
    where: { id: req.params.id },
    data: { status: "REJECTED", rejectionReason: reason, reviewedAt: new Date(), reviewedById: req.user!.id }
  });
  await audit(req, { action: "INVESTMENT_REJECTED", entityType: "InvestmentRequest", entityId: result.id, metadata: { reason } });
  ok(res, result);
}));

export default router;
