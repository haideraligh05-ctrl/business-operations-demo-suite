import { Router } from "express";
import { prisma } from "../config/prisma.js";
import { requireAuth } from "../common/auth.js";
import { asyncHandler, ok } from "../common/http.js";

const router = Router();

router.get("/", requireAuth, asyncHandler(async (req, res) => {
  const user = await prisma.user.findUnique({
    where: { id: req.user!.id },
    select: {
      id: true,
      email: true,
      firstName: true,
      lastName: true,
      role: true,
      status: true,
      emailVerifiedAt: true,
      wallet: true,
      kycRecord: true
    }
  });
  ok(res, user);
}));

export default router;
