import { Router } from "express";
import { z } from "zod";
import { UserRole } from "../generated/prisma/index.js";
import { prisma } from "../config/prisma.js";
import { requireAuth, requireRole } from "../common/auth.js";
import { AppError, asyncHandler, created, ok, validate } from "../common/http.js";
import { audit } from "../common/audit.js";
import { decimal } from "../common/money.js";
import { storePrivateFile, upload } from "../common/upload.js";

const router = Router();

router.get("/me", requireAuth, asyncHandler(async (req, res) => {
  const wallet = await prisma.wallet.findUnique({
    where: { userId: req.user!.id },
    include: { transactions: { orderBy: { createdAt: "desc" }, take: 20 } }
  });
  ok(res, wallet);
}));

router.post("/funding-requests", requireAuth, upload.single("proof"), asyncHandler(async (req, res) => {
  const { amount } = validate(z.object({ amount: z.coerce.number().positive() }), req.body);
  const file = req.file ? await storePrivateFile(req.file, `funding/${req.user!.id}`) : undefined;
  const request = await prisma.fundingRequest.create({
    data: {
      userId: req.user!.id,
      amount,
      proofFileKey: file?.fileKey,
      proofFileName: file?.fileName
    }
  });
  await audit(req, { action: "WALLET_FUNDING_REQUESTED", entityType: "FundingRequest", entityId: request.id, metadata: { amount } });
  created(res, request);
}));

router.get("/funding-requests", requireAuth, asyncHandler(async (req, res) => {
  const requests = await prisma.fundingRequest.findMany({ where: { userId: req.user!.id }, orderBy: { createdAt: "desc" } });
  ok(res, requests);
}));

router.get("/admin/funding-requests", requireAuth, requireRole(UserRole.ADMIN), asyncHandler(async (_req, res) => {
  const requests = await prisma.fundingRequest.findMany({ include: { user: true }, orderBy: { createdAt: "desc" } });
  ok(res, requests);
}));

router.post("/admin/funding-requests/:id/approve", requireAuth, requireRole(UserRole.ADMIN), asyncHandler(async (req, res) => {
  const result = await prisma.$transaction(async (tx) => {
    const funding = await tx.fundingRequest.findUnique({ where: { id: req.params.id } });
    if (!funding || funding.status !== "PENDING") throw new AppError(422, "Funding request cannot be approved");

    const wallet = await tx.wallet.findUnique({ where: { userId: funding.userId } });
    if (!wallet) throw new AppError(404, "Wallet not found");

    const balanceAfter = decimal(wallet.balance).plus(funding.amount);
    await tx.wallet.update({ where: { id: wallet.id }, data: { balance: balanceAfter } });
    await tx.walletTransaction.create({
      data: {
        walletId: wallet.id,
        type: "FUNDING",
        direction: "CREDIT",
        amount: funding.amount,
        balanceAfter,
        reference: funding.id,
        description: "Funding request approved"
      }
    });
    return tx.fundingRequest.update({
      where: { id: funding.id },
      data: { status: "APPROVED", reviewedAt: new Date(), reviewedById: req.user!.id }
    });
  });

  await audit(req, { action: "WALLET_APPROVED", entityType: "FundingRequest", entityId: result.id });
  ok(res, result);
}));

router.post("/admin/funding-requests/:id/reject", requireAuth, requireRole(UserRole.ADMIN), asyncHandler(async (req, res) => {
  const { reason } = validate(z.object({ reason: z.string().min(1) }), req.body);
  const result = await prisma.fundingRequest.update({
    where: { id: req.params.id },
    data: { status: "REJECTED", rejectionReason: reason, reviewedAt: new Date(), reviewedById: req.user!.id }
  });
  await audit(req, { action: "WALLET_REJECTED", entityType: "FundingRequest", entityId: result.id, metadata: { reason } });
  ok(res, result);
}));

router.post("/admin/wallets/:userId/adjust", requireAuth, requireRole(UserRole.ADMIN), asyncHandler(async (req, res) => {
  const input = validate(z.object({ amount: z.coerce.number(), description: z.string().min(1) }), req.body);
  const result = await prisma.$transaction(async (tx) => {
    const wallet = await tx.wallet.findUnique({ where: { userId: req.params.userId } });
    if (!wallet) throw new AppError(404, "Wallet not found");
    const balanceAfter = decimal(wallet.balance).plus(input.amount);
    if (balanceAfter.lessThan(0)) throw new AppError(422, "Adjustment would make wallet negative");
    await tx.wallet.update({ where: { id: wallet.id }, data: { balance: balanceAfter } });
    return tx.walletTransaction.create({
      data: {
        walletId: wallet.id,
        type: "ADJUSTMENT",
        direction: input.amount >= 0 ? "CREDIT" : "DEBIT",
        amount: Math.abs(input.amount),
        balanceAfter,
        description: input.description
      }
    });
  });
  await audit(req, { action: "WALLET_ADJUSTED", entityType: "User", entityId: req.params.userId, metadata: input });
  ok(res, result);
}));

export default router;
