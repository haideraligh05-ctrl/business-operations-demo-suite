import { Router } from "express";
import { stringify } from "csv-stringify/sync";
import XLSX from "xlsx";
import PDFDocument from "pdfkit";
import { UserRole } from "../generated/prisma/index.js";
import { prisma } from "../config/prisma.js";
import { requireAuth, requireRole } from "../common/auth.js";
import { asyncHandler } from "../common/http.js";

const router = Router();

type ReportRow = Record<string, string | number | null>;

function sendRows(res: import("express").Response, rows: ReportRow[], name: string, format: string) {
  if (format === "xlsx") {
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet(rows), "Report");
    const buffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });
    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    res.setHeader("Content-Disposition", `attachment; filename="${name}.xlsx"`);
    return res.send(buffer);
  }

  if (format === "pdf") {
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="${name}.pdf"`);
    const doc = new PDFDocument({ margin: 36 });
    doc.pipe(res);
    doc.fontSize(18).text(`Investment Operations ${name} Report`);
    doc.moveDown();
    rows.slice(0, 100).forEach((row) => doc.fontSize(9).text(JSON.stringify(row)));
    return doc.end();
  }

  res.setHeader("Content-Type", "text/csv");
  res.setHeader("Content-Disposition", `attachment; filename="${name}.csv"`);
  return res.send(stringify(rows, { header: true }));
}

router.get("/admin/reports/users", requireAuth, requireRole(UserRole.ADMIN), asyncHandler(async (req, res) => {
  const users = await prisma.user.findMany({ include: { kycRecord: true, wallet: true }, orderBy: { createdAt: "desc" } });
  const rows = users.map((user) => ({
    id: user.id,
    email: user.email,
    name: `${user.firstName} ${user.lastName}`,
    role: user.role,
    status: user.status,
    kycStatus: user.kycRecord?.status ?? null,
    walletBalance: user.wallet?.balance.toString() ?? "0"
  }));
  sendRows(res, rows, "users", String(req.query.format ?? "csv"));
}));

router.get("/admin/reports/wallet-transactions", requireAuth, requireRole(UserRole.ADMIN), asyncHandler(async (req, res) => {
  const rows = await prisma.walletTransaction.findMany({ include: { wallet: { include: { user: true } } }, orderBy: { createdAt: "desc" } });
  sendRows(res, rows.map((tx) => ({
    id: tx.id,
    user: tx.wallet.user.email,
    type: tx.type,
    direction: tx.direction,
    amount: tx.amount.toString(),
    balanceAfter: tx.balanceAfter.toString(),
    createdAt: tx.createdAt.toISOString()
  })), "wallet-transactions", String(req.query.format ?? "csv"));
}));

router.get("/admin/reports/investments", requireAuth, requireRole(UserRole.ADMIN), asyncHandler(async (req, res) => {
  const rows = await prisma.portfolioHolding.findMany({ include: { user: true, investment: true }, orderBy: { createdAt: "desc" } });
  sendRows(res, rows.map((holding) => ({
    id: holding.id,
    user: holding.user.email,
    investment: holding.investment.title,
    principalAmount: holding.principalAmount.toString(),
    currentValue: holding.currentValue.toString(),
    status: holding.status,
    maturityDate: holding.maturityDate.toISOString()
  })), "investments", String(req.query.format ?? "csv"));
}));

router.get("/admin/audit-logs", requireAuth, requireRole(UserRole.ADMIN), asyncHandler(async (_req, res) => {
  const logs = await prisma.auditLog.findMany({ include: { actor: true }, orderBy: { createdAt: "desc" }, take: 500 });
  res.json({ data: logs });
}));

export default router;
