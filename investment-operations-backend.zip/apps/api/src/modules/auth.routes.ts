import { Router } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import crypto from "crypto";
import { z } from "zod";
import { prisma } from "../config/prisma.js";
import { env } from "../config/env.js";
import { AppError, asyncHandler, created, ok, validate } from "../common/http.js";
import { requireAuth, signAccessToken, signRefreshToken } from "../common/auth.js";
import { audit } from "../common/audit.js";

const router = Router();

const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  phone: z.string().optional()
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1)
});

function hashToken(token: string) {
  return crypto.createHash("sha256").update(token).digest("hex");
}

async function issueTokens(user: { id: string; email: string; role: "INVESTOR" | "ADMIN" }) {
  const refreshPlain = crypto.randomBytes(48).toString("hex");
  const refresh = await prisma.refreshToken.create({
    data: {
      userId: user.id,
      tokenHash: hashToken(refreshPlain),
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
    }
  });

  return {
    accessToken: signAccessToken(user),
    refreshToken: signRefreshToken({ userId: user.id, tokenId: refresh.id }) + "." + refreshPlain
  };
}

router.post("/register", asyncHandler(async (req, res) => {
  const input = validate(registerSchema, req.body);
  const existing = await prisma.user.findUnique({ where: { email: input.email.toLowerCase() } });
  if (existing) throw new AppError(409, "Email already registered");

  const passwordHash = await bcrypt.hash(input.password, env.BCRYPT_ROUNDS);
  const user = await prisma.user.create({
    data: {
      email: input.email.toLowerCase(),
      passwordHash,
      firstName: input.firstName,
      lastName: input.lastName,
      phone: input.phone,
      wallet: { create: {} },
      kycRecord: { create: {} }
    },
    select: { id: true, email: true, firstName: true, lastName: true, role: true }
  });

  const verificationToken = crypto.randomBytes(32).toString("hex");
  await prisma.emailVerificationToken.create({
    data: {
      userId: user.id,
      tokenHash: hashToken(verificationToken),
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000)
    }
  });

  created(res, { user, verificationToken });
}));

router.post("/login", asyncHandler(async (req, res) => {
  const input = validate(loginSchema, req.body);
  const user = await prisma.user.findUnique({ where: { email: input.email.toLowerCase() } });
  const success = user ? await bcrypt.compare(input.password, user.passwordHash) : false;

  await audit(req, {
    action: "LOGIN_ATTEMPT",
    entityType: "User",
    entityId: user?.id,
    metadata: { email: input.email, success }
  });

  if (!user || !success || user.deletedAt || user.status !== "ACTIVE") {
    throw new AppError(401, "Invalid credentials");
  }

  const tokens = await issueTokens({ id: user.id, email: user.email, role: user.role });
  ok(res, {
    user: { id: user.id, email: user.email, firstName: user.firstName, lastName: user.lastName, role: user.role },
    ...tokens
  });
}));

router.post("/refresh", asyncHandler(async (req, res) => {
  const { refreshToken } = validate(z.object({ refreshToken: z.string().min(1) }), req.body);
  const [jwtPart, plain] = refreshToken.split(".");
  if (!jwtPart || !plain) throw new AppError(401, "Invalid refresh token");

  const payload = jwt.verify(jwtPart, env.JWT_REFRESH_SECRET) as { userId: string; tokenId: string };
  const stored = await prisma.refreshToken.findUnique({ where: { id: payload.tokenId }, include: { user: true } });
  if (!stored || stored.revokedAt || stored.expiresAt < new Date() || stored.tokenHash !== hashToken(plain)) {
    throw new AppError(401, "Invalid refresh token");
  }

  await prisma.refreshToken.update({ where: { id: stored.id }, data: { revokedAt: new Date() } });
  const tokens = await issueTokens({ id: stored.user.id, email: stored.user.email, role: stored.user.role });
  ok(res, tokens);
}));

router.post("/logout", requireAuth, asyncHandler(async (req, res) => {
  await prisma.refreshToken.updateMany({ where: { userId: req.user!.id, revokedAt: null }, data: { revokedAt: new Date() } });
  ok(res, { success: true });
}));

router.post("/verify-email", asyncHandler(async (req, res) => {
  const { token } = validate(z.object({ token: z.string().min(1) }), req.body);
  const record = await prisma.emailVerificationToken.findFirst({
    where: { tokenHash: hashToken(token), usedAt: null, expiresAt: { gt: new Date() } }
  });
  if (!record) throw new AppError(400, "Invalid verification token");

  await prisma.$transaction([
    prisma.emailVerificationToken.update({ where: { id: record.id }, data: { usedAt: new Date() } }),
    prisma.user.update({ where: { id: record.userId }, data: { emailVerifiedAt: new Date() } })
  ]);
  ok(res, { success: true });
}));

router.post("/forgot-password", asyncHandler(async (req, res) => {
  const { email } = validate(z.object({ email: z.string().email() }), req.body);
  const user = await prisma.user.findUnique({ where: { email: email.toLowerCase() } });
  if (!user) return ok(res, { success: true });

  const token = crypto.randomBytes(32).toString("hex");
  await prisma.passwordResetToken.create({
    data: {
      userId: user.id,
      tokenHash: hashToken(token),
      expiresAt: new Date(Date.now() + 60 * 60 * 1000)
    }
  });
  ok(res, { success: true, resetToken: token });
}));

router.post("/reset-password", asyncHandler(async (req, res) => {
  const input = validate(z.object({ token: z.string(), password: z.string().min(8) }), req.body);
  const record = await prisma.passwordResetToken.findFirst({
    where: { tokenHash: hashToken(input.token), usedAt: null, expiresAt: { gt: new Date() } }
  });
  if (!record) throw new AppError(400, "Invalid reset token");

  await prisma.$transaction([
    prisma.passwordResetToken.update({ where: { id: record.id }, data: { usedAt: new Date() } }),
    prisma.user.update({ where: { id: record.userId }, data: { passwordHash: await bcrypt.hash(input.password, env.BCRYPT_ROUNDS) } })
  ]);
  ok(res, { success: true });
}));

export default router;
