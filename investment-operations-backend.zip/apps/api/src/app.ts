import express from "express";
import helmet from "helmet";
import cors from "cors";
import cookieParser from "cookie-parser";
import rateLimit from "express-rate-limit";
import swaggerUi from "swagger-ui-express";
import { env } from "./config/env.js";
import { errorHandler } from "./common/http.js";
import authRoutes from "./modules/auth.routes.js";
import meRoutes from "./modules/me.routes.js";
import kycRoutes from "./modules/kyc.routes.js";
import walletRoutes from "./modules/wallet.routes.js";
import investmentRoutes from "./modules/investments.routes.js";
import portfolioRoutes from "./modules/portfolio.routes.js";
import userRoutes from "./modules/users.routes.js";
import reportRoutes from "./modules/reports.routes.js";
import { openApiSpec } from "./docs/openapi.js";

export const app = express();

app.use(helmet());
app.use(cors({ origin: env.WEB_ORIGIN, credentials: true }));
app.use(cookieParser());
app.use(express.json({ limit: "1mb" }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 300 }));

app.get("/health", (_req, res) => res.json({ status: "ok" }));
app.use("/api/docs", swaggerUi.serve, swaggerUi.setup(openApiSpec));
app.use("/api/auth", authRoutes);
app.use("/api/me", meRoutes);
app.use("/api/kyc", kycRoutes);
app.use("/api/wallet", walletRoutes);
app.use("/api/investments", investmentRoutes);
app.use("/api/portfolio", portfolioRoutes);
app.use("/api", userRoutes);
app.use("/api", reportRoutes);
app.use(errorHandler);
