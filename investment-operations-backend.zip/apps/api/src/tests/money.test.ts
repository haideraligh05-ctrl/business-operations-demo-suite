import { describe, expect, it } from "vitest";
import { decimal } from "../common/money.js";

describe("money helpers", () => {
  it("keeps decimal arithmetic precise for wallet operations", () => {
    expect(decimal("100.10").plus("0.20").toString()).toBe("100.3");
    expect(decimal("100.10").minus("50.05").toString()).toBe("50.05");
  });

  it("can detect insufficient balances", () => {
    expect(decimal("1000").lessThan("1001")).toBe(true);
    expect(decimal("1000").lessThan("999")).toBe(false);
  });
});
