import type { Request } from "express";
import type { AuditAction, Prisma } from "../generated/prisma/index.js";
import { prisma } from "../config/prisma.js";

export async function audit(req: Request, input: {
  action: AuditAction;
  entityType: string;
  entityId?: string;
  metadata?: Prisma.InputJsonValue;
}) {
  await prisma.auditLog.create({
    data: {
      actorId: req.user?.id,
      action: input.action,
      entityType: input.entityType,
      entityId: input.entityId,
      metadata: input.metadata,
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"]
    }
  });
}
