import multer from "multer";
import { AppError } from "./http.js";

const allowed = new Set(["image/jpeg", "image/png", "application/pdf"]);

export const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (!allowed.has(file.mimetype)) return cb(new AppError(422, "Only PDF, JPG, and PNG files are allowed"));
    cb(null, true);
  }
});

export async function storePrivateFile(file: Express.Multer.File, prefix: string) {
  // Production path: stream this buffer to private S3 and return the object key.
  return {
    fileKey: `${prefix}/${Date.now()}-${file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_")}`,
    fileName: file.originalname,
    mimeType: file.mimetype,
    size: file.size
  };
}
