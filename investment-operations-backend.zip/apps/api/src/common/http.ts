import type { NextFunction, Request, Response } from "express";
import { ZodError, type ZodSchema } from "zod";

export class AppError extends Error {
  constructor(
    public statusCode: number,
    message: string,
    public details?: unknown
  ) {
    super(message);
  }
}

export const asyncHandler =
  (handler: (req: Request, res: Response, next: NextFunction) => Promise<unknown>) =>
  (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(handler(req, res, next)).catch(next);
  };

export function validate<T>(schema: ZodSchema<T>, data: unknown): T {
  try {
    return schema.parse(data);
  } catch (error) {
    if (error instanceof ZodError) {
      throw new AppError(422, "Validation failed", error.flatten());
    }
    throw error;
  }
}

export function errorHandler(error: unknown, _req: Request, res: Response, _next: NextFunction) {
  if (error instanceof AppError) {
    return res.status(error.statusCode).json({ message: error.message, details: error.details });
  }

  console.error(error);
  return res.status(500).json({ message: "Internal server error" });
}

export function created(res: Response, data: unknown) {
  return res.status(201).json({ data });
}

export function ok(res: Response, data: unknown) {
  return res.json({ data });
}
