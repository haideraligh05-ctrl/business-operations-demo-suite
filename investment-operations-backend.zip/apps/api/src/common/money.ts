import { Prisma } from "../generated/prisma/index.js";

export function decimal(value: number | string | Prisma.Decimal) {
  return new Prisma.Decimal(value);
}
