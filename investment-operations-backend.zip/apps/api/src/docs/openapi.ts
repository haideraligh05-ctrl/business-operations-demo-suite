export const openApiSpec = {
  openapi: "3.0.3",
  info: {
    title: "Investment Operations API",
    version: "0.1.0",
    description: "Secure MVP API for investor onboarding, KYC, wallet funding, investment execution, portfolio tracking, and administration."
  },
  servers: [{ url: "/api" }],
  components: {
    securitySchemes: {
      bearerAuth: { type: "http", scheme: "bearer", bearerFormat: "JWT" }
    }
  },
  security: [{ bearerAuth: [] }],
  paths: {
    "/auth/register": { post: { summary: "Register an investor" } },
    "/auth/login": { post: { summary: "Login and receive access and refresh tokens" } },
    "/auth/refresh": { post: { summary: "Rotate refresh token and issue a new access token" } },
    "/kyc/me": { get: { summary: "Get my KYC" }, put: { summary: "Update my KYC draft" } },
    "/kyc/me/submit": { post: { summary: "Submit KYC for admin review" } },
    "/wallet/me": { get: { summary: "Get wallet balance and recent transactions" } },
    "/wallet/funding-requests": { get: { summary: "List my funding requests" }, post: { summary: "Create funding request" } },
    "/investments": { get: { summary: "List active investments" } },
    "/investments/requests": { post: { summary: "Create investment request" } },
    "/portfolio/me": { get: { summary: "List my portfolio holdings" } },
    "/admin/users": { get: { summary: "Admin user search" } },
    "/admin/reports/users": { get: { summary: "Export users report" } }
  }
};
