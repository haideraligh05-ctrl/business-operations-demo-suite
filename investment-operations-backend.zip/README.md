# Investment Operations Backend

An anonymized source edition of the original Express, TypeScript and PostgreSQL MVP. The routes cover onboarding, KYC review, wallet funding requests, investment approvals, portfolio records and reporting.

## Run on a development machine

Use Node.js 22.12 or newer, npm and a disposable local PostgreSQL database. From the extracted folder, run `npm install`, then switch to `apps/api`.

Copy `../../.env.example` to `.env`, set `DATABASE_URL` to the disposable database and generate two distinct secrets with `openssl rand -hex 32`. Then run:

```sh
npm run db:generate
npm exec -- prisma db push
npm run db:seed
npm run dev
```

The seed command generates local demo credentials. The API listens on localhost. See `http://127.0.0.1:4000/health` and `http://127.0.0.1:4000/api/docs`. Run `npm test` in `apps/api` for the included arithmetic tests.

This MVP uses simulated funding. The KYC upload path produces metadata and still needs durable private file storage for production use. Use fictional identities and documents.
