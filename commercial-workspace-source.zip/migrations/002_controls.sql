CREATE TABLE IF NOT EXISTS request_keys(actor TEXT NOT NULL REFERENCES users(id),entity TEXT NOT NULL,request_id TEXT NOT NULL,record_id TEXT NOT NULL,PRIMARY KEY(actor,entity,request_id));
CREATE TABLE IF NOT EXISTS merges(entity TEXT NOT NULL,source_id TEXT NOT NULL,target_id TEXT NOT NULL,actor TEXT NOT NULL REFERENCES users(id),occurred_at TEXT NOT NULL,reason TEXT NOT NULL,evidence TEXT NOT NULL,PRIMARY KEY(entity,source_id));
CREATE TRIGGER IF NOT EXISTS adjustment_no_update BEFORE UPDATE ON adjustments BEGIN SELECT RAISE(ABORT,'Adjustments are immutable'); END;
CREATE TRIGGER IF NOT EXISTS adjustment_no_delete BEFORE DELETE ON adjustments BEGIN SELECT RAISE(ABORT,'Adjustments are immutable'); END;
CREATE TRIGGER IF NOT EXISTS reward_no_update BEFORE UPDATE ON reward_ledger BEGIN SELECT RAISE(ABORT,'Reward ledger is immutable'); END;
CREATE TRIGGER IF NOT EXISTS reward_no_delete BEFORE DELETE ON reward_ledger BEGIN SELECT RAISE(ABORT,'Reward ledger is immutable'); END;
CREATE TRIGGER IF NOT EXISTS allocation_no_update BEFORE UPDATE ON payment_allocations BEGIN SELECT RAISE(ABORT,'Receipt allocations are immutable; reverse receipt and re-enter correction'); END;
CREATE TRIGGER IF NOT EXISTS allocation_no_delete BEFORE DELETE ON payment_allocations BEGIN SELECT RAISE(ABORT,'Receipt allocations are immutable'); END;
