import csv, io
from .models import MODULES
from .service import save

def preview(db,actor,table,text):
    if table not in ('contacts','leads','boq_lines'):raise ValueError('CSV import supports contacts, leads and BOQ lines')
    reader=csv.DictReader(io.StringIO(text.lstrip('\ufeff')))
    if not reader.fieldnames:raise ValueError('CSV header is required')
    result=[];seen=set()
    for i,row in enumerate(reader,2):
        if i>502:raise ValueError('Import limited to 500 rows')
        key=(row.get('email') or row.get('code') or row.get('title') or '').strip().lower()
        errors=[]
        if key in seen:errors.append('Duplicate row in import')
        seen.add(key)
        field='email' if table=='contacts' else 'code' if table=='boq_lines' else 'title'
        if row.get(field) and db.execute(f'SELECT 1 FROM {table} WHERE lower({field})=lower(?)',(row[field],)).fetchone():errors.append('Possible duplicate already exists')
        db.execute('SAVEPOINT import_preview')
        try:save(db,actor,table,row)
        except (ValueError,Exception) as e:errors.append(str(e))
        finally:db.execute('ROLLBACK TO import_preview');db.execute('RELEASE import_preview')
        result.append(dict(row=i,data=row,errors=errors))
    return result
