"""Permission-safe progress and recognition summaries."""
import json
from datetime import date, timedelta
from .db import record, setting

def progress(db,missions):
    accepted=applicable=0
    for m in missions:
        template=json.loads(m['calendar_snapshot']) if m.get('calendar_snapshot') else record(db,'mission_templates',m['template_id'])
        if not template.get('required') or m['status']=='Skipped':continue
        weight=template.get('weight') or 1;applicable+=weight
        if m['status']=='Accepted':accepted+=weight
    return {'accepted':accepted,'applicable':applicable,'ratio':accepted/applicable if applicable else None}

def recognition(db,actor):
    # Only the actor's own qualification is shown; no client information in a leaderboard.
    rule=setting(db,'scoring',{'badge':5,'weekly_goal':10})
    eligible=db.execute("SELECT COUNT(*) FROM missions m WHERE m.owner_id=? AND m.status='Accepted' AND m.rejected_count=0 AND NOT EXISTS(SELECT 1 FROM reward_ledger r WHERE r.mission_id=m.id AND r.kind='Reversal')",(actor.id,)).fetchone()[0]
    monday=(date.today()-timedelta(days=date.today().weekday())).isoformat()
    weekly=db.execute("SELECT COUNT(*) FROM missions m WHERE m.status='Accepted' AND substr(m.accepted_at,1,10)>=? AND NOT EXISTS(SELECT 1 FROM reward_ledger r WHERE r.mission_id=m.id AND r.kind='Reversal')",(monday,)).fetchone()[0]
    return dict(first_pass=eligible,badge=eligible>=rule['badge'],badge_threshold=rule['badge'],weekly=weekly,goal=rule['weekly_goal'])

def lifecycle(db,opportunity_id):
    from .service import cash,net,blockers
    op=record(db,'opportunities',opportunity_id)
    orders=[dict(r) for r in db.execute('SELECT * FROM orders WHERE opportunity_id=?',(opportunity_id,))]
    missions=[dict(r) for r in db.execute('SELECT * FROM missions WHERE opportunity_id=?',(opportunity_id,))]
    def mission(term):
        found=[m for m in missions if term in m['title'].lower()]
        return 'Completed' if found and all(m['status'] in ('Accepted','Skipped') for m in found) else 'Blocked' if any(m['blocked'] for m in found) else 'Current' if any(m['ready_at'] for m in found) else 'Upcoming'
    approval=list(db.execute('SELECT a.decision FROM approvals a JOIN technical_requests t ON t.id=a.technical_request_id WHERE t.opportunity_id=? AND a.mandatory=1',(opportunity_id,)))
    banked=bool(orders) and all(db.execute('SELECT 1 FROM bank_events WHERE order_id=?',(o['id'],)).fetchone() for o in orders)
    return [('Enquiry','Completed' if db.execute('SELECT 1 FROM enquiry_cycles WHERE opportunity_id=?',(opportunity_id,)).fetchone() else 'Current'),('BOQ',mission('boq')),('Design',mission('design')),('Costing',mission('costing')),('Proposal',mission('proposal')),('Approvals','Completed' if approval and all(a[0]=='Approved' for a in approval) else 'Blocked' if approval else 'Upcoming'),('Banking','Completed' if banked else 'Current' if orders else 'Upcoming'),('Production','Blocked' if any(blockers(db,o['id'],'production') for o in orders) else 'Completed' if orders and all(o['execution'] not in ('Technical Approvals','Production Release') for o in orders) else 'Upcoming'),('Delivery','Completed' if orders and all(o['execution'] in ('Delivered','Operational Completion') for o in orders) else 'Upcoming'),('Collections','Completed' if banked and all(cash(db,o['id'])>=net(db,o['id']) for o in orders) else 'Current' if banked else 'Upcoming')]
