import csv, io, json, os, secrets, sqlite3, time
from pathlib import Path
from functools import wraps
from flask import Flask, g, session, request, redirect, url_for, render_template, jsonify, abort, flash, send_file, Response
from werkzeug.security import check_password_hash
from werkzeug.utils import secure_filename
from .db import ROOT, connect, migrate, transaction, now, uid, audit, record, insert, setting
from .models import MODULES, STAGES, ROLES
from .security import Actor, allowed, visible, serialize, authorize, require, Forbidden
from .service import save, get, rows, action, Conflict, blockers, cash, net
from .reporting import metrics, automation, notifications, FILTERS
from .clocks import clock
from .imports import preview
from .workflow import progress, recognition, lifecycle

NAV=[('Workspace',[('overview','Overview'),('my_day','My Day'),('accounts','Accounts'),('contacts','Contacts'),('leads','Leads'),('enquiries','Enquiries / RFQ'),('opportunities','Opportunities'),('projects','Projects / Stores')]),('Commercial',[('boqs','BOQ'),('quotations','Quotations / PI'),('technical_requests','R&D / Approvals'),('orders','Orders')]),('Operations',[('milestones','Production / Execution'),('shipments','Shipments / Delivery'),('invoices','Collections / Payments'),('claims','Claims / After Sales'),('documents','Documents'),('missions','Missions / Handoffs')]),('Management',[('reports','Reports'),('admin','Administration')])]

def create_app(config=None):
    app=Flask(__name__,template_folder=str(ROOT/'templates'),static_folder=str(ROOT/'static'))
    app.config.update(DATABASE=str(ROOT/'instance/greenlight.db'),UPLOAD_FOLDER=str(ROOT/'instance/uploads'),MAX_CONTENT_LENGTH=10*1024*1024,SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SAMESITE='Lax',PERMANENT_SESSION_LIFETIME=3600,DEMO=False)
    if config:app.config.update(config)
    Path(app.config['DATABASE']).parent.mkdir(parents=True,exist_ok=True)
    Path(app.config['UPLOAD_FOLDER']).mkdir(parents=True,exist_ok=True)
    secret=os.environ.get('GREENLIGHT_SECRET')
    if not secret:
        key=Path(app.config['DATABASE']).parent/'session.key'
        if not key.exists():key.write_text(secrets.token_hex(32))
        secret=key.read_text()
    app.secret_key=secret
    db=connect(app.config['DATABASE']);migrate(db);db.close()
    attempts={}

    @app.before_request
    def context():
        g.db=connect(app.config['DATABASE']);g.actor=None;g.user=None
        if session.get('user_id'):
            user=g.db.execute('SELECT * FROM users WHERE id=? AND active=1',(session['user_id'],)).fetchone()
            roles=[r[0] for r in g.db.execute('SELECT role FROM user_roles WHERE user_id=?',(session['user_id'],))]
            if user and session.get('role') in roles:g.user=dict(user);g.actor=Actor(user['id'],session['role']);g.roles=roles
            else:session.clear()
        if request.endpoint not in ('login','static','health') and not g.actor:
            if request.path.startswith('/api/'):abort(401)
            return redirect(url_for('login'))
        if request.method=='POST' and not app.config.get('TESTING'):
            supplied=request.form.get('csrf') or request.headers.get('X-CSRF-Token')
            if not supplied or not secrets.compare_digest(supplied,session.get('csrf','')):abort(400,description='Session token expired. Reload and try again.')

    @app.teardown_request
    def close(error):
        if getattr(g,'db',None):g.db.close()

    @app.after_request
    def headers(response):
        response.headers['X-Content-Type-Options']='nosniff';response.headers['X-Frame-Options']='DENY'
        response.headers['Referrer-Policy']='same-origin';response.headers['Cache-Control']='no-store'
        response.headers['Content-Security-Policy']="default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
        return response

    @app.context_processor
    def helpers():
        def title(table,id):
            if not id:return '—'
            try:
                r=record(g.db,table,id)
                if table=='users':return r['name']
                return r['title'] if visible(g.db,g.actor,table,r) else 'Restricted record'
            except ValueError:return id
        def display(f,v):
            if v is None or v=='':return '—'
            if f.kind=='money':return f'{v/100:,.2f}'
            if f.ref:return title(f.ref,v)
            if f.kind=='check':return 'Yes' if v else 'No'
            return v
        nav=[]
        if g.actor:
            for label,items in NAV:
                items=[(key,text) for key,text in items if (allowed(g.actor,key) if key in MODULES else key not in ('overview','reports','admin') or (g.actor.role!='R&D' and (key!='admin' or g.actor.role in ('Manager','Administrator'))))]
                if items:nav.append((label,items))
        return dict(modules=MODULES,nav=nav,actor=g.actor,user=g.user,roles=getattr(g,'roles',[]),csrf=session.setdefault('csrf',secrets.token_urlsafe(32)),request_id=secrets.token_urlsafe(20),can=lambda t,w=False:bool(g.actor and allowed(g.actor,t,w)),title=title,display=display,money=lambda n:f'${(n or 0)/100:,.0f}',today=now()[:10],demo=setting(g.db,'demo',False),stages=STAGES)

    @app.route('/brand/aligh-nexus-monogram')
    def brand_monogram():
        return send_file(ROOT/'Powered by'/'Untitled.jpg', mimetype='image/jpeg')

    @app.route('/brand/aligh-nexus-card')
    def brand_card():
        return send_file(ROOT/'Powered by'/'aligh_nexus_footer_card_real_qr.png', mimetype='image/png')

    @app.route('/health')
    def health():return jsonify(status='ok',database=g.db.execute('PRAGMA quick_check').fetchone()[0])

    @app.route('/login',methods=['GET','POST'])
    def login():
        if request.method=='POST':
            key=(request.remote_addr,request.form.get('email','').lower());times=[t for t in attempts.get(key,[]) if time.time()-t<300]
            if len(times)>=8:abort(429,description='Too many attempts. Try again in five minutes.')
            user=g.db.execute('SELECT * FROM users WHERE lower(email)=? AND active=1',(key[1],)).fetchone()
            if user and check_password_hash(user['password_hash'],request.form.get('password','')):
                session.clear();session.update(user_id=user['id'],role=g.db.execute('SELECT role FROM user_roles WHERE user_id=? ORDER BY role',(user['id'],)).fetchone()[0],csrf=secrets.token_urlsafe(32));session.permanent=True
                attempts.pop(key,None);return redirect(url_for('home'))
            attempts[key]=times+[time.time()];flash('Email or password was not recognized.','error')
        return render_template('login.html')

    @app.post('/logout')
    def logout():session.clear();return redirect(url_for('login'))

    @app.post('/role')
    def role():
        role=request.form.get('role')
        if role not in g.roles:raise Forbidden('Role has not been granted to this user')
        with transaction(g.db):audit(g.db,g.actor.id,g.actor.role,'users',g.actor.id,'active role',g.actor.role,role)
        session['role']=role;return redirect(url_for('home'))

    @app.route('/')
    def home():return redirect(url_for('my_day') if g.actor.role=='R&D' else url_for('overview'))

    @app.route('/overview')
    def overview():
        if g.actor.role=='R&D':raise Forbidden('Commercial reporting is restricted')
        m=metrics(g.db,g.actor,request.args);m['progress']=progress(g.db,m['missions'])
        return render_template('overview.html',page='overview',m=m,filters=request.args,filter_options=filter_options(),blockers=lambda id:blockers(g.db,id,'production'))

    def filter_options():
        ops=rows(g.db,g.actor,'opportunities')
        return {k:sorted({str(r[k]) for r in ops if r.get(k)}) for k in FILTERS}

    @app.route('/my-day')
    def my_day():
        with transaction(g.db):automation(g.db)
        missions=rows(g.db,g.actor,'missions')
        team=request.args.get('team')=='1'
        missions=[m for m in missions if team or m['owner_id']==g.actor.id or m['receiver_id']==g.actor.id]
        for m in missions:
            raw=record(g.db,'missions',m['id']);m['clock']=clock(g.db,raw,now())
            o=record(g.db,'opportunities',raw['opportunity_id'])
            # Safe context for an already-authorized mission; no commercial values or free-form notes.
            m['context']={'client':record(g.db,'accounts',o['account_id'])['title'],'project':record(g.db,'projects',o['project_id'])['title'] if o['project_id'] else 'No project','stage':o['stage']}
        rewards=g.db.execute('SELECT COALESCE(SUM(points),0) FROM reward_ledger WHERE actor=?',(g.actor.id,)).fetchone()[0]
        next_actions=[]
        for table in ('opportunities','technical_requests','activities','invoices','milestones','claims'):
            if allowed(g.actor,table):
                for r in rows(g.db,g.actor,table):
                    if r['owner_id']==g.actor.id and r['next_action'] and r['due_date']<=now()[:10]:next_actions.append(dict(table=table,**r))
        return render_template('my_day.html',page='my_day',missions=missions,alerts=notifications(g.db,g.actor),points=rewards,team=team,recognition=recognition(g.db,g.actor),next_actions=next_actions[:20])

    @app.route('/records/<table>')
    def listing(table):
        items=rows(g.db,g.actor,table);q=request.args.get('q','').lower()
        items=[r for r in items if q in json.dumps(r).lower()]
        for key in ('owner_id','stage','status','country','opportunity_id','order_id','boq_id','project_id','technical_request_id','record_id'):
            if request.args.get(key):items=[r for r in items if str(r.get(key,''))==request.args[key]]
        return render_template('list.html',page=table,table=table,items=items,heading=MODULES[table][0],board=request.args.get('view')=='board')

    def choices(table,current=None):
        choices={}
        for f in MODULES[table][1]:
            if f.ref=='users':choices[f.name]=[dict(id=r['id'],title=r['name']) for r in g.db.execute('SELECT id,name FROM users WHERE active=1')]
            elif f.ref:
                choices[f.name]=rows(g.db,g.actor,f.ref) if allowed(g.actor,f.ref) else []
                if current and current.get(f.name) and not any(x['id']==current[f.name] for x in choices[f.name]):
                    choices[f.name].append(dict(id=current[f.name],title='Current linked scope (unchanged)'))
        choices['owner_id']=[dict(id=r['id'],title=r['name']) for r in g.db.execute('SELECT id,name FROM users WHERE active=1')]
        return choices

    @app.route('/records/<table>/new',methods=['GET','POST'])
    @app.route('/records/<table>/<id>/edit',methods=['GET','POST'])
    def edit(table,id=None):
        authorize(g.db,g.actor,table,write=True)
        r=get(g.db,g.actor,table,id) if id else dict(request.args)
        error=None
        if request.method=='POST':
            try:
                data=request.form.to_dict()
                for f in MODULES[table][1]:
                    if f.kind=='check':data[f.name]=request.form.get(f.name,'0')
                with transaction(g.db):out=save(g.db,g.actor,table,data,id)
                flash('Record saved.','success');return redirect(url_for('detail',table=table,id=out['id']))
            except (ValueError,sqlite3.IntegrityError) as e:error=str(e);r=request.form.to_dict()
        return render_template('form.html',page=table,table=table,r=r,editing=bool(id),options=choices(table,r),error=error,posted=request.method=='POST')

    @app.route('/records/<table>/<id>')
    def detail(table,id):
        raw=get(g.db,g.actor,table,id);r=serialize(g.actor,table,raw);extra={}
        related=[]
        for child,(_,fields) in MODULES.items():
            if not allowed(g.actor,child):continue
            for f in fields:
                if f.ref==table:
                    rs=[x for x in rows(g.db,g.actor,child) if x.get(f.name)==id]
                    related.append((child,f.name,rs))
        history=[] if g.actor.role in ('R&D','Read only') else [dict(x) for x in g.db.execute('SELECT * FROM audit_events WHERE entity=? AND record_id=? ORDER BY occurred_at DESC,rowid DESC',(table,id))]
        if table=='orders':extra=dict(cash=cash(g.db,id),net=net(g.db,id),production=blockers(g.db,id,'production'),loading=blockers(g.db,id,'loading'),exceptions=[dict(x) for x in g.db.execute('SELECT * FROM exceptions WHERE order_id=?',(id,))])
        if table=='missions':extra=dict(clock=clock(g.db,raw,now()),handoffs=[dict(x) for x in g.db.execute('SELECT * FROM handoffs WHERE mission_id=? ORDER BY revision',(id,))],holds=[dict(x) for x in g.db.execute('SELECT * FROM holds WHERE mission_id=?',(id,))])
        if table=='opportunities':
            extra['cycles']=[dict(x) for x in g.db.execute('SELECT * FROM enquiry_cycles WHERE opportunity_id=?',(id,))]
            extra['journey']=rows(g.db,g.actor,'missions');extra['journey']=[x for x in extra['journey'] if x.get('opportunity_id')==id]
            extra['progress']=progress(g.db,extra['journey'])
            extra['lifecycle']=lifecycle(g.db,id)
        docs=[d for d in rows(g.db,g.actor,'documents') if d['record_type']==table and d['record_id']==id]
        activities=[d for d in rows(g.db,g.actor,'activities') if d['record_type']==table and d['record_id']==id]
        return render_template('detail.html',page=table,table=table,r=r,extra=extra,related=related,history=history,docs=docs,activities=activities)

    @app.post('/records/<table>/<id>/action/<name>')
    def do_action(table,id,name):
        with transaction(g.db):out=action(g.db,g.actor,table,id,name,request.form.to_dict())
        if out and out.startswith('orders:'):table='orders';out=out.split(':',1)[1]
        flash('Action recorded in the audit trail.','success');return redirect(url_for('detail',table=table,id=out or id))

    @app.route('/api/<table>',methods=['GET','POST'])
    @app.route('/api/<table>/<id>',methods=['GET','PATCH'])
    def api(table,id=None):
        if request.method=='GET':return jsonify(serialize(g.actor,table,get(g.db,g.actor,table,id)) if id else rows(g.db,g.actor,table))
        if request.method=='PATCH' and not app.config.get('TESTING') and request.headers.get('X-CSRF-Token')!=session.get('csrf'):abort(400)
        with transaction(g.db):result=save(g.db,g.actor,table,request.get_json() or {},id)
        return jsonify(serialize(g.actor,table,result)),201 if not id else 200

    @app.post('/api/<table>/<id>/actions/<name>')
    def api_action(table,id,name):
        with transaction(g.db):out=action(g.db,g.actor,table,id,name,request.get_json() or {})
        return jsonify(id=out)

    @app.route('/export/<table>')
    def export(table):
        items=rows(g.db,g.actor,table)
        q=request.args.get('q','').lower();items=[r for r in items if q in json.dumps(r).lower()]
        for key,value in request.args.items():
            if key in FILTERS or key in ('order_id','opportunity_id','boq_id','status'):items=[r for r in items if str(r.get(key,''))==value]
        return csv_response(items,table)

    def csv_response(items,name):
        buffer=io.StringIO();keys=list(items[0]) if items else ['No records'];writer=csv.DictWriter(buffer,keys);writer.writeheader()
        for r in items:writer.writerow({k:("'"+v if isinstance(v,str) and v.startswith(('=','+','-','@','\t','\r')) else v) for k,v in r.items()})
        return Response(buffer.getvalue(),mimetype='text/csv',headers={'Content-Disposition':f'attachment; filename="Commercial Workspace-GreenLight-{name}.csv"'})

    @app.route('/reports')
    def reports():
        if g.actor.role=='R&D':raise Forbidden('Commercial reporting is restricted')
        m=metrics(g.db,g.actor,request.args);kind=request.args.get('kind','pipeline');items=[]
        if kind in ('pipeline','weighted','forecast','slippage','stale','missing-actions','win-loss'):
            items=m['opportunities']
            if kind=='pipeline' or kind=='weighted':items=m['open_ops']
            if kind=='slippage':items=[r for r in items if r['expected_banking'] and r['original_forecast'] and r['expected_banking']>r['original_forecast']]
            if kind=='missing-actions':items=[r for r in items if not r['next_action']]
            if kind=='stale':items=[r for r in items if (time.time()-__import__('datetime').datetime.fromisoformat(r['updated_at']).timestamp())>14*86400]
            if kind=='win-loss':items=m['won']+m['lost']
        elif kind in ('banked','balances','loading-holds','delivery-risks'):
            items=m['cohort'] if kind=='banked' else m['orders']
            items=[{**r,'net_banked':net(g.db,r['id']),'cash_received':cash(g.db,r['id']),'contractual_balance':r['value']-cash(g.db,r['id']),'loading_holds':'; '.join(blockers(g.db,r['id'],'loading'))} for r in items]
            if kind=='loading-holds':items=[r for r in items if r['loading_holds']]
            if kind=='delivery-risks':items=[r for r in items if r['forecast_delivery'] and r['opening_date'] and r['forecast_delivery']>r['opening_date']]
        elif kind=='ageing':items=m['invoices']
        elif kind=='cash':
            accounts={r['account_id'] for r in m['orders']};items=[r for r in rows(g.db,g.actor,'payments') if r['account_id'] in accounts and r['verified_at'] and m['start']<=r['receipt_date']<=m['end']]
        elif kind=='commitments':items=[r for r in rows(g.db,g.actor,'milestones') if r['order_id'] in {o['id'] for o in m['orders']}]
        elif kind in ('missions','handoffs'):
            items=[{k:v for k,v in r.items() if k!='clock'} for r in m['missions'] if kind=='missions' or r['status']=='Pending acceptance']
        elif kind=='snapshots':items=[dict(r) for r in g.db.execute('SELECT * FROM forecast_snapshots') if r['opportunity_id'] in {o['id'] for o in m['opportunities']}]
        if request.args.get('export'):return csv_response(items,kind)
        return render_template('reports.html',page='reports',m=m,items=items,kind=kind,filters=request.args,filter_options=filter_options())

    @app.post('/snapshot')
    def snapshot():
        require(g.actor,('Manager','Administrator'))
        with transaction(g.db):
            for r in rows(g.db,g.actor,'opportunities'):insert(g.db,'forecast_snapshots',dict(id=uid('SNP'),opportunity_id=r['id'],snapshot_at=now(),value=r['value'] or 0,expected_banking=r['expected_banking'],probability=r['probability'],stage=r['stage']))
            audit(g.db,g.actor.id,g.actor.role,'forecast_snapshots','all','snapshot')
        return redirect(url_for('reports',kind='snapshots'))

    @app.route('/import/<table>',methods=['GET','POST'])
    def importer(table):
        authorize(g.db,g.actor,table,write=True);results=[];text=''
        if request.method=='POST':
            text=request.form.get('csv','')
            with transaction(g.db):
                results=preview(g.db,g.actor,table,text)
                if request.form.get('commit')=='1':
                    if not results or any(r['errors'] for r in results):raise ValueError('Resolve row errors before committing')
                    for r in results:save(g.db,g.actor,table,r['data'])
                    flash(f'{len(results)} rows imported.','success');return redirect(url_for('listing',table=table))
        return render_template('import.html',page=table,table=table,results=results,text=text)

    @app.post('/upload')
    def upload():
        file=request.files.get('file');data=request.form.to_dict()
        if not file or not file.filename:raise ValueError('Choose a file')
        filename=secure_filename(file.filename);ext=Path(filename).suffix.lower()
        if ext not in ('.pdf','.png','.jpg','.jpeg','.csv','.txt','.dwg','.dxf','.xlsx','.docx'):raise ValueError('Unsupported file type')
        content=file.read()
        if ext=='.pdf' and not content.startswith(b'%PDF'):raise ValueError('Invalid PDF signature')
        if ext=='.png' and not content.startswith(b'\x89PNG'):raise ValueError('Invalid PNG signature')
        if ext in ('.jpg','.jpeg') and not content.startswith(b'\xff\xd8'):raise ValueError('Invalid JPEG signature')
        storage=secrets.token_hex(24)+ext;path=Path(app.config['UPLOAD_FOLDER'])/storage
        try:
            with transaction(g.db):
                r=save(g.db,g.actor,'documents',data)
                previous=data.get('previous_id') or None;version=1
                if previous:
                    p=get(g.db,g.actor,'documents',previous)
                    if (p['record_type'],p['record_id'],p['permission'])!=(r['record_type'],r['record_id'],r['permission']):raise ValueError('Document versions must preserve record and permission')
                    version=p['document_version']+1
                path.write_bytes(content)
                g.db.execute('UPDATE documents SET filename=?,storage_name=?,uploaded_by=?,previous_id=?,document_version=? WHERE id=?',(filename,storage,g.actor.id,previous,version,r['id']))
        except Exception:
            path.unlink(missing_ok=True);raise
        return redirect(url_for('detail',table=data['record_type'],id=data['record_id']))

    @app.route('/download/<id>')
    def download(id):
        d=get(g.db,g.actor,'documents',id);get(g.db,g.actor,d['record_type'],d['record_id'])
        if g.actor.role=='R&D' and d['permission']!='Technical':raise Forbidden('Restricted attachment')
        if not d['storage_name']:raise ValueError('No file has been uploaded')
        return send_file(Path(app.config['UPLOAD_FOLDER'])/d['storage_name'],as_attachment=True,download_name=d['filename'])

    @app.route('/admin',methods=['GET','POST'])
    def admin():
        require(g.actor,('Manager','Administrator'))
        if request.method=='POST':
            key=request.form.get('key')
            if key not in ('scoring','alerts','commercial'):raise ValueError('Invalid configuration')
            value=json.loads(request.form['value'])
            defaults={'scoring':{'version':1,'accepted':10,'on_time':2,'badge':5,'weekly_goal':10},'alerts':{'amber':.8,'escalation_days':1},'commercial':{'max_discount':10,'minimum_margin':15}}
            if set(value)!=set(defaults[key]) or any(not isinstance(v,(int,float)) or v<0 for v in value.values()):raise ValueError('Keep the documented numeric keys and nonnegative values')
            with transaction(g.db):
                old=setting(g.db,key)
                if key=='scoring':value['version']=(old or {'version':0})['version']+1
                g.db.execute('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,version=version+1',(key,json.dumps(value)))
                audit(g.db,g.actor.id,g.actor.role,'settings',key,'configure',old,value,request.form.get('reason',''))
            flash('Configuration saved; existing mission snapshots remain unchanged.','success')
        return render_template('admin.html',page='admin',settings={k:json.dumps(setting(g.db,k),indent=2) for k in ('scoring','alerts','commercial')},events=[dict(r) for r in g.db.execute('SELECT * FROM audit_events ORDER BY occurred_at DESC,rowid DESC LIMIT 100')])

    @app.errorhandler(ValueError)
    @app.errorhandler(sqlite3.IntegrityError)
    def domain_error(e):
        status=403 if isinstance(e,Forbidden) else 409 if isinstance(e,Conflict) else 422
        msg='A duplicate or invalid linked record was rejected.' if isinstance(e,sqlite3.IntegrityError) else str(e)
        if request.path.startswith('/api/'):return jsonify(error=msg),status
        return render_template('error.html',message=msg),status
    return app
