import json
import sqlite3
import sys
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from .models import MODULES, EXTRA_SQL

ROOT = Path(sys._MEIPASS) if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent.parent

def now():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')

def uid(prefix='REC'):
    return prefix.upper()[:5] + '-' + uuid.uuid4().hex[:12]

def connect(path):
    db = sqlite3.connect(str(path), timeout=15, isolation_level=None)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    db.execute('PRAGMA journal_mode=WAL')
    return db

@contextmanager
def transaction(db):
    db.execute('BEGIN IMMEDIATE')
    try:
        yield
        db.commit()
    except Exception:
        db.rollback()
        raise

def migrate(db):
    # Forward references are resolved by SQLite once all tables exist.
    db.execute('CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1)')
    for table, (_, fields) in MODULES.items():
        columns = ['id TEXT PRIMARY KEY','title TEXT NOT NULL','owner_id TEXT REFERENCES users(id)',"next_action TEXT NOT NULL DEFAULT ''",'due_date TEXT',"blocked TEXT NOT NULL DEFAULT ''",'version INTEGER NOT NULL DEFAULT 1','created_at TEXT NOT NULL','updated_at TEXT NOT NULL']
        for f in fields:
            typ = 'INTEGER' if f.kind in ('money','check') else 'REAL' if f.kind=='number' else 'TEXT'
            columns.append(f'{f.name} {typ}' + (f' REFERENCES {f.ref}(id)' if f.ref else ''))
        if table in EXTRA_SQL:
            columns.append(EXTRA_SQL[table])
        db.execute(f'CREATE TABLE IF NOT EXISTS {table}({",".join(columns)})')
        db.execute(f'CREATE INDEX IF NOT EXISTS {table}_owner ON {table}(owner_id)')
    db.executescript((ROOT/'migrations/001_core.sql').read_text())
    db.executescript((ROOT/'migrations/002_controls.sql').read_text())
    mission_columns={r[1] for r in db.execute('PRAGMA table_info(missions)')}
    if 'approved_due' not in mission_columns:db.execute('ALTER TABLE missions ADD COLUMN approved_due TEXT')
    db.execute('CREATE UNIQUE INDEX IF NOT EXISTS payment_reference ON payments(account_id,reference,currency)')
    db.execute('CREATE UNIQUE INDEX IF NOT EXISTS brand_account ON brand_relationships(account_id,brand_id,country)')
    db.execute('CREATE UNIQUE INDEX IF NOT EXISTS boq_code ON boq_lines(boq_id,code)')
    db.execute('CREATE UNIQUE INDEX IF NOT EXISTS shipment_line ON shipment_allocations(shipment_id,order_line_id)')
    db.execute('INSERT OR IGNORE INTO schema_migrations VALUES(1,?)',(now(),))
    db.execute('INSERT OR IGNORE INTO schema_migrations VALUES(2,?)',(now(),))

def insert(db, table, data):
    keys=list(data)
    db.execute(f'INSERT INTO {table} ({",".join(keys)}) VALUES ({",".join("?" for _ in keys)})',list(data.values()))
    return data.get('id')

def record(db, table, id):
    if table not in MODULES and table not in ('users','handoffs','holds'):
        raise ValueError('Unknown record type')
    row=db.execute(f'SELECT * FROM {table} WHERE id=?',(id,)).fetchone()
    if not row: raise ValueError('Record not found')
    return dict(row)

def setting(db, key, default=None):
    r=db.execute('SELECT value FROM settings WHERE key=?',(key,)).fetchone()
    return json.loads(r[0]) if r else default

def audit(db, actor, role, entity, id, action, old=None, new=None, reason=''):
    insert(db,'audit_events',dict(id=uid('AUD'),actor=actor,role=role,occurred_at=now(),entity=entity,record_id=id,action=action,old_value=json.dumps(old,default=str),new_value=json.dumps(new,default=str),reason=reason))
