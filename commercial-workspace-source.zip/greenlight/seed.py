"""Explicit opt-in demonstration data; never run on application startup."""
import json, secrets
from datetime import date, timedelta
from pathlib import Path
from werkzeug.security import generate_password_hash
from .db import now, insert, uid, audit
from .security import Actor
from .service import bank, action, start_mission

def seed(db,upload_folder,password=None):
    if db.execute('SELECT 1 FROM users').fetchone():raise ValueError('Seed requires an empty database; existing records are preserved')
    password=password or secrets.token_urlsafe(16)
    users=[('qazi','Demo Sales Lead','qazi@demo.commercial.local',('Sales','Manager','Administrator')),('processor','Demo Order Processor','processor@demo.commercial.local',('Processor',)),('rnd','Demo Technical Reviewer','rnd@demo.commercial.local',('R&D',)),('viewer','Management Viewer','viewer@demo.commercial.local',('Read only',))]
    for id,name,email,roles in users:
        insert(db,'users',dict(id=id,name=name,email=email,password_hash=generate_password_hash(password)))
        for role in roles:db.execute('INSERT INTO user_roles VALUES(?,?)',(id,role))
    for key,value in {'demo':True,'scoring':{'version':1,'accepted':10,'on_time':2,'badge':5,'weekly_goal':10},'alerts':{'amber':.8,'escalation_days':1},'commercial':{'max_discount':10,'minimum_margin':15}}.items():db.execute('INSERT INTO settings(key,value) VALUES(?,?)',(key,json.dumps(value)))
    def day(n=0):return (date.today()+timedelta(days=n)).isoformat()
    def add(table,id,title,**kwargs):
        r=dict(id=id,title=title,owner_id='qazi',next_action='Review scope and agree next step',due_date=day(3),blocked='',version=1,created_at=now(),updated_at=now())
        r.update(kwargs);insert(db,table,r);return id
    actor=Actor('qazi','Manager')
    add('groups','GROUP-01','Crescent Hospitality Group',country='UAE')
    for id,title,country in [('ACC-01','Crescent Dining UAE','UAE'),('ACC-02','Crescent Restaurants KSA','Saudi Arabia'),('ACC-03','Karachi Coffee Company','Pakistan')]:
        add('accounts',id,title,parent_id='GROUP-01' if id!='ACC-03' else None,country=country,company_type='Operating company',billing_address=country,team='Middle East' if country!='Pakistan' else 'Pakistan')
    for id,title in [('BRAND-01','Juniper Kitchen'),('BRAND-02','Saffron & Co.'),('BRAND-03','Common Ground Coffee')]:add('brands',id,title,description='Fictional demonstration brand')
    for i in range(1,4):
        add('brand_relationships',f'REL-0{i}',f'Brand operation {i}',account_id=f'ACC-0{i}',brand_id=f'BRAND-0{i}',country=['UAE','Saudi Arabia','Pakistan'][i-1])
        add('contacts',f'CON-0{i}',['Demo Contact A','Demo Contact B','Demo Contact C'][i-1],account_id=f'ACC-0{i}',email=f'buyer{i}@example.test',phone='+000 DEMO',contact_role='Procurement lead',decision_authority='Final scope and commercial sign-off',preferred_channel='Email',lead_source='Referral')
        add('projects',f'PROJ-0{i}',['Dubai dining rollout','Riyadh flagship','Karachi café refresh'][i-1],account_id=f'ACC-0{i}',brand_id=f'BRAND-0{i}',country=['UAE','Saudi Arabia','Pakistan'][i-1],opening_date=day(70))
        add('stores',f'STORE-0{i}',['Dubai Marina','Riyadh Olaya','Clifton'][i-1],project_id=f'PROJ-0{i}',account_id=f'ACC-0{i}',country=['UAE','Saudi Arabia','Pakistan'][i-1],address='Demo delivery address',opening_date=day(70))
    add('products','PROD-01','Arden dining chair',code='ARD-001',description='Upholstered timber dining chair',dimensions='520 × 540 × 800 mm',materials='Ash frame',finish='Natural oak',source='Malaysia hub',cost=9000,selling_price=18000)
    stages=['Awaiting PO / Advance','Scope and Costing','Quotation Submitted','Negotiation','Qualified','Banked / Closed Won','Closed Lost','On Hold']
    titles=['Juniper · Dubai Marina seating','Saffron · Riyadh flagship','Common Ground · Clifton refresh','Juniper · Abu Dhabi terrace','Saffron · Jeddah rollout','Juniper · Downtown dining','Common Ground · Airport kiosk','Saffron · Dammam concept']
    amounts=[160000,245000,85000,120000,310000,180000,45000,90000]
    for i,(stage,title,value) in enumerate(zip(stages,titles,amounts),1):
        n=(i-1)%3+1;id=f'OPP-{i:02}'
        add('opportunities',id,title,account_id=f'ACC-0{n}',contact_id=f'CON-0{n}',brand_id=f'BRAND-0{n}',project_id=f'PROJ-0{n}',country=['UAE','Saudi Arabia','Pakistan'][n-1],team='Pakistan' if n==3 else 'Middle East',currency='USD',value=value*100,fx_rate=1,fx_source='Demo USD base',fx_date=day(),probability=[80,35,50,65,20,100,0,15][i-1],confidence='High' if i in (1,6) else 'Medium',expected_banking=day(20),original_forecast=day(10),source='Referral',need='Restaurant furniture supply',buyer=f'CON-0{n}',scope='Furniture and upholstered seating',assumptions='Layout supplied; final finishes pending',technical_queries='Confirm local finish',cost_request='Malaysia factory quote requested',feedback='Review finish swatches',decision_process='Procurement then operations approval',risks='Opening date depends on finish approval',agreed_scope='Dining seating',confirmation='Demo client confirmation',stage=stage,closed_at=now() if i in (6,7) else None,reason_code='Design fit' if i==6 else 'Price' if i==7 else None,explanation='Demonstration decision evidence',review_date=day(7) if i==8 else None,next_action=['Verify advance and approve finish','Complete BOQ costing','Follow up on submitted proposal','Confirm revised quantities','Qualify buyer and opening date','Review delivery milestone','Capture competitor lessons','Review project restart date'][i-1])
        add('enquiries',f'ENQ-{i:02}',f'RFQ · {title}',opportunity_id=id,rfq_date=day(-7),customer_deadline=day(7),store_opening=day(70),scope_categories='Seating, tables',layout_reference='DEMO layout reference',source_documents='Manual RFQ',clarifications='Finish to be confirmed',promised_response=day(3))
        insert(db,'enquiry_cycles',dict(id=f'CYCLE-{i:02}',opportunity_id=id,started_at=day(-12)+'T08:00:00+00:00',ended_at=now() if i in (6,7) else None))
    # Genuine separate currency transaction to exercise filters and frozen conversion.
    add('opportunities','OPP-09','Saffron · Khobar lounge',account_id='ACC-02',brand_id='BRAND-02',project_id='PROJ-02',country='Saudi Arabia',team='Middle East',currency='SAR',value=37500000,fx_rate=0.2666666667,fx_source='Demo planning rate',fx_date=day(),probability=25,confidence='Medium',stage='Qualified',source='Client RFQ',need='Lounge seating',buyer='CON-02',scope='Lounge furniture',expected_banking=day(45),original_forecast=day(45))
    for i in (1,2,3,6):
        add('boqs',f'BOQ-{i:02}',f'BOQ · {titles[i-1]}',opportunity_id=f'OPP-{i:02}',exclusions='Installation and local tax',assumptions='Final approved quantities',missing_drawings='Ceiling coordination drawing pending' if i==2 else '')
        add('boq_lines',f'BLINE-{i:02}','Arden dining chair · natural finish',boq_id=f'BOQ-{i:02}',product_id='PROD-01',code='ARD-001',description='Dining chair',quantity=100,unit='pcs',source='Malaysia',cost=9000,selling_price=18000,dimensions='520 × 540 × 800 mm',materials='Ash frame',finish='Natural oak',oem_option='OEM frame approved',alternative='Upholstered seat option')
    upload_folder=Path(upload_folder);upload_folder.mkdir(parents=True,exist_ok=True)
    for i in (1,3,6):
        doc=f'DOC-Q-{i}';filename=f'demo-quotation-{i}.txt';(upload_folder/filename).write_text(f'DEMONSTRATION QUOTATION {i}\nScope: seating\nPrice USD {amounts[i-1]}\nNot a commercial offer.')
        add('documents',doc,'Client-issued quotation · demo',record_type='opportunities',record_id=f'OPP-{i:02}',document_type='Quotation',permission='Commercial',source='Demonstration fixture',filename=filename,storage_name=filename,uploaded_by='processor')
        add('quotations',f'QUO-{i:02}',titles[i-1],opportunity_id=f'OPP-{i:02}',boq_id=f'BOQ-{i:02}',document_type='Quotation',currency='USD',scope='Accepted seating package',quantity=100,unit_price=amounts[i-1],discount=0,freight=0,total=amounts[i-1]*100,cost=amounts[i-1]*50,incoterm='FOB',validity=day(14),lead_time_basis='Verified advance and technical approvals',payment_schedule='50% advance, 50% pre-loading',terms='Demo standard terms',client_document=doc,follow_up=day(),status='Issued',issued_at=day(-3)+'T09:00:00+00:00',accepted_at=now() if i in (1,6) else None,accepted_evidence='Demo client acceptance of exact scope and price' if i in (1,6) else None,family_id=f'QUO-{i:02}')
    # Banked partial award: 100k of 160k; the 60k stays in the pipeline.
    for i,value in [(1,100000),(6,180000)]:
        n=(i-1)%3+1;id=f'ORD-{i:02}'
        add('orders',id,titles[i-1],opportunity_id=f'OPP-{i:02}',quotation_id=f'QUO-{i:02}',account_id=f'ACC-0{n}',contact_id=f'CON-0{n}',terms='50% advance, 50% pre-loading',currency='USD',value=value*100,advance_required=value*50,fx_rate=1,fx_source='Demo USD base',fx_date=day(),factory='Malaysia hub',delivery_address=['Dubai Marina','Clifton'][i==6],opening_date=day(45),forecast_delivery=day(52 if i==1 else 30),shipping_days=14,customs_days=4,confirmed_at=day(-3)+'T09:00:00+00:00',confirmation_evidence='DEMO customer email',po_valid_at=day(-2)+'T09:00:00+00:00')
        filename=f'demo-po-{i}.txt';(upload_folder/filename).write_text(f'DEMONSTRATION PO for {id}; no commercial validity')
        add('documents',f'PO-{i:02}','Customer PO · demo',record_type='orders',record_id=id,document_type='PO',permission='Commercial',source='Demo customer',filename=filename,storage_name=filename,uploaded_by='processor')
        db.execute('UPDATE orders SET po_id=? WHERE id=?',(f'PO-{i:02}',id))
        add('payments',f'PAY-{i:02}','Advance receipt · demo',account_id=f'ACC-0{n}',currency='USD',amount=value*50,receipt_date=day(-1),reference=f'DEMO-RECEIPT-{i}',finance_confirmation='DEMO bank statement verified',evidence='Demonstration finance confirmation',verified_at=now(),verified_by='qazi',owner_id='processor')
        add('invoices',f'INV-A-{i}','Advance invoice',order_id=id,schedule='Advance',due_trigger='PO',currency='USD',amount=value*50,credits=0,due_date=day(-4),owner_id='processor')
        add('payment_allocations',f'ALLOC-{i}','Advance allocation',payment_id=f'PAY-{i:02}',order_id=id,invoice_id=f'INV-A-{i}',amount=value*50)
        bank(db,actor,id)
        add('invoices',f'INV-B-{i}','Pre-loading balance',order_id=id,schedule='Pre-loading balance',due_trigger='Ready to load',currency='USD',amount=value*50,credits=0,due_date=day(-2 if i==6 else 25),promised_date=day(3),collection_task='Confirm balance before loading',owner_id='processor')
        add('order_lines',f'OL-{i}','Seating allocation',order_id=id,boq_line_id=f'BLINE-{i:02}',store_id=f'STORE-0{n}',product_id='PROD-01',quantity=100,unit_price=value,batch='Batch A',execution='Technical Approvals')
        add('milestones',f'MILE-{i}','Production commitment',order_id=id,original_baseline=day(20),client_requested=day(18),commitment=day(20),forecast=day(27 if i==1 else 20),trigger='Technical approvals',duration_days=20,day_basis='working',factory='Malaysia hub',owner_id='processor')
    add('orders','ORD-02','Juniper · remaining scope draft',opportunity_id='OPP-01',quotation_id='QUO-01',account_id='ACC-01',currency='USD',value=6000000,advance_required=3000000,fx_rate=1,fx_source='Demo base rate',fx_date=day(),factory='China hub')
    add('technical_requests','TECH-01','Dubai Marina · finish confirmation',opportunity_id='OPP-01',order_id='ORD-01',brief='Confirm local oak stain against store sample',request_type='Finish',priority='High',material_source='Internally sourced',owner_id='rnd',next_action='Submit local finish swatch for approval',due_date=day())
    add('approvals','APP-01','Local oak finish · revision B',technical_request_id='TECH-01',order_id='ORD-01',item='Oak stain',item_revision='B',approver_id='rnd',requested_date=day(-5),scope_level='Store',store_id='STORE-01',brand_id='BRAND-01',country='UAE',mandatory=1,owner_id='rnd',due_date=day(),next_action='Compare swatch and record decision')
    add('samples','SAMPLE-01','Oak swatch · Dubai Marina',technical_request_id='TECH-01',sample_status='Client review',dispatch_date=day(-6),received_date=day(-2),material_source='Internally sourced',owner_id='rnd')
    for i,quantity in [(1,40),(2,60)]:
        add('shipments',f'SHIP-0{i}',f'Downtown seating · shipment {i}',order_id='ORD-06',factory='Malaysia hub',origin='Port Klang',destination='Dubai',cbm=quantity*.2,packing='Protective cartons',freight_validity=day(10),freight_charges=200000,booking=f'DEMO-BOOKING-{i}',etd=day(-7 if i==1 else 14),eta=day(-1 if i==1 else 28),clearance='Cleared' if i==1 else 'Pending',proof_of_delivery='DEMO signed delivery note' if i==1 else None,status='Delivered' if i==1 else 'Planned',delivered_at=now() if i==1 else None,owner_id='processor')
        add('shipment_allocations',f'SALLOC-0{i}',f'Chair allocation {i}',shipment_id=f'SHIP-0{i}',order_line_id='OL-6',quantity=quantity)
    add('claims','CLAIM-01','Downtown · scratched chair leg',order_id='ORD-06',order_line_id='OL-6',claim_type='Damage',photos='Demo photo reference',cost=9000,corrective_action='Replace one chair leg',client_acceptance='Pending',owner_id='processor')
    add('stock','STOCK-01','Customer reserve · Arden chairs',account_id='ACC-01',product_id='PROD-01',quantity=20,location='Malaysia reserve bay',approval_status='Approved',call_off=5)
    for i,(name,days,role) in enumerate([('BOQ preparation',3,'Sales'),('Design shortlisting',3,'R&D'),('Costing',5,'Processor'),('Proposal',3,'Processor'),('Samples',40,'R&D'),('Client feedback',3,'Sales')],1):
        add('mission_templates',f'TPL-{i}',name,duration_days=days,day_basis='working',timezone='Asia/Dubai',workweek='0,1,2,3,4',holidays='',required_inputs='Approved scope and supporting evidence',dependencies='Previous accepted deliverable',checklist='Scope checked; quantities reconciled; evidence attached',owner_role=role,required=1,weight=1,complexity=1)
        add('missions',f'MIS-{i}',name,opportunity_id='OPP-01',template_id=f'TPL-{i}',receiver_id='qazi',owner_id='rnd' if role=='R&D' else 'processor',inputs_evidence='DEMO scope and drawings available',dependency_id=f'MIS-{i-1}' if i>1 else None,next_action=['Review BOQ deliverable','Approve shortlisted finish','Obtain factory costs','Prepare client proposal','Confirm sample requirement','Record client decision'][i-1],due_date=day(0 if i<3 else 7))
    from .db import record
    action(db,actor,'quotations','QUO-03','revise',{'version':1})
    start_mission(db,actor,record(db,'missions','MIS-1'))
    action(db,actor,'missions','MIS-1','submit',{'version':2,'evidence':'DEMO reviewed BOQ with reconciled quantities','checklist':'complete'})
    action(db,actor,'missions','MIS-1','accept',{})
    # A real running mission on approved hold, retaining its original due date.
    m=record(db,'missions','MIS-2')
    action(db,actor,'missions','MIS-2','hold',{'version':m['version'],'kind':'Client waiting','reason':'Waiting for local sample review','evidence':'DEMO client review request','review_date':day()})
    db.execute("UPDATE missions SET blocked='Client finish decision pending' WHERE id='MIS-2'")
    template=record(db,'mission_templates','TPL-3')
    add('missions','MIS-OVERDUE','Riyadh · factory costing',opportunity_id='OPP-02',template_id='TPL-3',receiver_id='qazi',owner_id='processor',inputs_evidence='Demo approved scope',next_action='Submit reconciled supplier costs',due_date=day(-2),status='Active',ready_at=day(-12)+'T08:00:00+00:00',assigned_at=day(-12)+'T08:00:00+00:00',original_due=day(-2)+'T08:00:00+00:00',calendar_snapshot=json.dumps(template),rule_snapshot=json.dumps({'version':1,'accepted':10,'on_time':2,'badge':5,'weekly_goal':10}))
    add('activities','ACT-01','Client requested natural oak finish',record_type='technical_requests',record_id='TECH-01',activity_type='WhatsApp decision',source='Manually recorded demo decision',occurred_at=day(-2),notes='Client asked for natural oak finish; local approval remains pending.',owner_id='rnd')
    add('targets','TARGET-YEAR','Demonstration annual target',owner_id=None,period_start=f'{date.today().year}-01-01',period_end=f'{date.today().year}-12-31',period_type='Annual',amount=100000000,currency='USD',approved=1)
    audit(db,'qazi','Administrator','demo','seed','explicit demonstration seed',None,{'synthetic':True})
    return [(email,password) for _,_,email,_ in users]
