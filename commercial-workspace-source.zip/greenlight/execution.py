"""Forecast recalculation keeps approved commitments and baselines intact."""
from datetime import timedelta
from .db import record
from .clocks import deadline, dt

def forecast(db,order_id):
    order=record(db,'orders',order_id);dates=[];pending=[]
    bank=db.execute('SELECT effective_at FROM bank_events WHERE order_id=?',(order_id,)).fetchone()
    approvals=db.execute('SELECT decision,decided_at,scope_level FROM approvals WHERE order_id=? AND mandatory=1',(order_id,)).fetchall()
    technical_ready=bool(approvals) and all(a['decision']=='Approved' and a['scope_level']!='Global' for a in approvals)
    for row in db.execute('SELECT * FROM milestones WHERE order_id=?',(order_id,)):
        m=dict(row);trigger=bank[0] if m['trigger']=='Verified advance' and bank else max((a['decided_at'] for a in approvals),default=None) if m['trigger']=='Technical approvals' and technical_ready else None
        if m['dependency_id']:
            dependency=record(db,'milestones',m['dependency_id']);dependency_date=dependency['actual'] or dependency['forecast']
            if dependency_date:trigger=max(trigger or dependency_date,dependency_date)
            else:trigger=None
        if not trigger:pending.append(m['title']);continue
        calendar={'day_basis':m['day_basis'] or 'calendar','timezone':'Asia/Dubai','workweek':'0,1,2,3,4','holidays':m['holidays'] or ''}
        computed=deadline(trigger,(m['duration_days'] or 0)*86400,calendar)
        dates.append(max(computed[:10],m['forecast'] or computed[:10]))
    if not dates:return {'forecast':order['forecast_delivery'],'pending':pending,'risk':'Blocked' if pending else 'On track'}
    delivery=(dt(max(dates))+timedelta(days=(order['shipping_days'] or 0)+(order['customs_days'] or 0))).date().isoformat()
    return {'forecast':delivery,'pending':pending,'risk':'Blocked' if pending else 'At risk' if order['opening_date'] and delivery>order['opening_date'] else 'On track'}
