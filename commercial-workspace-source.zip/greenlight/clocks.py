"""Timezone-aware eligible days; one working day is a local calendar day.

DST days retain their actual elapsed duration. Calendar snapshots are immutable.
"""
from datetime import datetime, timedelta, timezone, time
from zoneinfo import ZoneInfo
import json

def dt(value):
    if isinstance(value,datetime): return value
    d=datetime.fromisoformat(value)
    return d.replace(tzinfo=timezone.utc) if d.tzinfo is None else d

def eligible(start, end, calendar):
    a,b=dt(start),dt(end)
    if b<=a:return 0.0
    if calendar['day_basis']=='calendar': return (b-a).total_seconds()
    zone=ZoneInfo(calendar['timezone'])
    day=a.astimezone(zone).date(); last=b.astimezone(zone).date()
    workweek=[int(x) for x in calendar['workweek'].split(',')]
    holidays=set((calendar.get('holidays') or '').replace(' ','').split(','))
    total=0
    while day<=last:
        if day.weekday() in workweek and day.isoformat() not in holidays:
            lo=datetime.combine(day,time(),zone).astimezone(timezone.utc)
            hi=datetime.combine(day+timedelta(days=1),time(),zone).astimezone(timezone.utc)
            total+=max(0,(min(b,hi)-max(a,lo)).total_seconds())
        day+=timedelta(days=1)
    return total

def deadline(start, seconds, calendar):
    if seconds<0: raise ValueError('Duration cannot be negative')
    a=dt(start); lo=a; hi=a+timedelta(days=max(2,seconds/86400*3+370))
    if eligible(a,hi,calendar)<seconds:raise ValueError('Calendar has insufficient eligible days')
    for _ in range(45):
        mid=lo+(hi-lo)/2
        if eligible(a,mid,calendar)<seconds:lo=mid
        else:hi=mid
    return hi.replace(microsecond=0).isoformat()

def clock(db, mission, at):
    if not mission.get('ready_at'):return dict(elapsed=0,remaining=0,overdue=0,external_wait=0,holding=False)
    cal=json.loads(mission['calendar_snapshot'])
    end=mission.get('completed_at') or at
    elapsed=eligible(mission['ready_at'],end,cal); external=0; holding=False
    for hold in db.execute('SELECT * FROM holds WHERE mission_id=?',(mission['id'],)):
        stop=min(dt(hold['end_at'] or end),dt(end)); start=max(dt(hold['start_at']),dt(mission['ready_at']))
        held=eligible(start,stop,cal)
        elapsed-=held
        if hold['kind'] in ('Client waiting','Supplier waiting'):external+=max(0,(stop-start).total_seconds())
        holding|=not bool(hold['end_at'])
    elapsed=max(0,elapsed); allowance=float(cal['duration_days'])*86400
    if mission.get('approved_due'):
        a,b=dt(mission['original_due']),dt(mission['approved_due'])
        allowance+=eligible(a,b,cal) if b>=a else -eligible(b,a,cal)
        allowance=max(0,allowance)
    return dict(elapsed=elapsed,remaining=max(0,allowance-elapsed),overdue=max(0,elapsed-allowance),external_wait=external,holding=holding)
