"""Record-derived metrics with explicit dates and banked cohorts."""
from datetime import date, timedelta
from .db import now, record, uid, insert, setting
from .service import rows, cash, net, blockers
from .clocks import clock, dt
from .security import visible, allowed

FILTERS=('owner_id','team','country','account_id','brand_id','project_id','stage','currency')
def ratio(a,b):return a/b if b else None
def matches(row,filters):return all(not filters.get(k) or str(row.get(k,''))==filters[k] for k in FILTERS)
def selected(db,actor,filters):return [r for r in rows(db,actor,'opportunities') if matches(r,filters)]
def metrics(db,actor,filters):
    start=filters.get('start') or f'{date.today().year}-01-01';end=filters.get('end') or f'{date.today().year}-12-31'
    date.fromisoformat(start);date.fromisoformat(end)
    if start>end:raise ValueError('Start date must precede end date')
    ops=selected(db,actor,filters);ids={o['id'] for o in ops}
    orders=[o for o in rows(db,actor,'orders') if o['opportunity_id'] in ids]
    cohort=[];gross=adjustments=received=0
    for o in orders:
        b=db.execute('SELECT * FROM bank_events WHERE order_id=?',(o['id'],)).fetchone()
        if b and start<=b['effective_at'][:10]<=end:
            cohort.append(o);gross+=b['usd_value']
            adjustments+=db.execute('SELECT COALESCE(SUM(usd_amount),0) FROM adjustments WHERE order_id=? AND substr(effective_at,1,10)<=?',(o['id'],end)).fetchone()[0]
            paid=db.execute('SELECT COALESCE(SUM(a.amount),0) FROM payment_allocations a JOIN payments p ON p.id=a.payment_id WHERE a.order_id=? AND p.verified_at IS NOT NULL AND substr(p.verified_at,1,10)<=? AND (p.reversed_at IS NULL OR substr(p.reversed_at,1,10)>?)',(o['id'],end,end)).fetchone()[0]
            received+=round(paid*float(b['fx_rate']))
    net_value=gross+adjustments;pipeline=on_hold=weighted=0;open_ops=[];stage_values={}
    for o in ops:
        awarded=db.execute('SELECT COALESCE(SUM(b.value),0) FROM bank_events b JOIN orders x ON x.id=b.order_id WHERE x.opportunity_id=?',(o['id'],)).fetchone()[0]
        remaining=max(0,(o['value'] or 0)-awarded)*(o['fx_rate'] or 1)
        if o['stage']=='On Hold':on_hold+=remaining
        elif o['stage'] not in ('Closed Lost','Banked / Closed Won'):
            pipeline+=remaining;weighted+=remaining*(o['probability'] or 0)/100
            if remaining:open_ops.append(o)
            stage_values[o['stage']]=stage_values.get(o['stage'],0)+remaining
    targets=[]
    for t in rows(db,actor,'targets'):
        if not t['approved'] or t['period_start']!=start or t['period_end']!=end:continue
        if any(filters.get(k) and t.get(k)!=filters[k] for k in FILTERS if k not in ('stage','currency')):continue
        targets.append(t)
    # An unfiltered total uses the unassigned overall target, preventing aggregate + assigned double counting.
    if not any(filters.get(k) for k in FILTERS):targets=[t for t in targets if not any(t.get(k) for k in ('country','account_id','brand_id','project_id','team')) and not t.get('owner_id')]
    target=sum(t['amount'] for t in targets);gap=max(0,target-net_value)
    won=[o for o in ops if o['stage']=='Banked / Closed Won' and start<=(o['closed_at'] or '')[:10]<=end]
    lost=[o for o in ops if o['stage']=='Closed Lost' and start<=(o['closed_at'] or '')[:10]<=end]
    overdue=0;invoice_rows=[]
    for inv in rows(db,actor,'invoices'):
        order=next((o for o in orders if o['id']==inv['order_id']),None)
        if not order:continue
        paid=db.execute('SELECT COALESCE(SUM(a.amount),0) FROM payment_allocations a JOIN payments p ON p.id=a.payment_id WHERE a.invoice_id=? AND p.verified_at IS NOT NULL AND p.reversed_at IS NULL',(inv['id'],)).fetchone()[0]
        balance=max(0,inv['amount']-(inv['credits'] or 0)-paid);age=max(0,(date.today()-date.fromisoformat(inv['due_date'])).days)
        inv.update(balance=balance,age=age,age_bucket='Current' if not age else '1–30' if age<=30 else '31–60' if age<=60 else '61–90' if age<=90 else '90+')
        invoice_rows.append(inv)
        if age:overdue+=balance*order['fx_rate']
    missions=[]
    for m in rows(db,actor,'missions'):
        if m.get('opportunity_id') not in ids:continue
        m['clock']=clock(db,m,now());missions.append(m)
    accepted=[m for m in missions if m['status']=='Accepted' and start<=(m['original_due'] or '')[:10]<=end]
    ontime=[m for m in accepted if m['accepted_at']<=(m.get('approved_due') or m['original_due'])]
    return dict(start=start,end=end,updated=now(),opportunities=ops,orders=orders,cohort=cohort,gross=gross,adjustments=adjustments,net=net_value,cash=received,pipeline=pipeline,on_hold=on_hold,weighted=weighted,target=target,gap=gap,achievement=ratio(net_value,target),coverage=ratio(pipeline,gap) if gap else None,win_rate=ratio(len(won),len(won)+len(lost)),cash_rate=ratio(received,net_value),won=won,lost=lost,open_ops=open_ops,stages=stage_values,overdue=overdue,invoices=invoice_rows,missions=missions,mission_performance=ratio(len(ontime),len(accepted)),first_pass=ratio(len([m for m in accepted if not m['rejected_count']]),len(accepted)))

def automation(db):
    """In-app scheduler: stable keys and reconciliation remove obsolete alerts."""
    db.execute('UPDATE notifications SET active=0')
    def notify(table,r,kind,message,owner=None):
        owner=owner or r.get('owner_id')
        if not owner:return
        db.execute('INSERT INTO notifications VALUES(?,?,?,?,?,?,?,1) ON CONFLICT(user_id,entity,record_id,category) DO UPDATE SET active=1,message=excluded.message',(uid('NOT'),owner,table,r['id'],kind,message,now()))
    today=date.today().isoformat()
    for table in ('missions','opportunities','quotations','approvals','orders'):
        for raw in db.execute(f'SELECT * FROM {table}'):
            r=dict(raw)
            if r.get('blocked'):notify(table,r,'blocker','Blocked: '+r['blocked'])
            if table=='missions' and r['ready_at'] and r['status'] not in ('Accepted','Skipped'):
                c=clock(db,r,now());allow=c['elapsed']+c['remaining']
                threshold=setting(db,'alerts',{'amber':.8,'escalation_days':1})
                if c['overdue']:notify(table,r,'overdue','Mission overdue; original commitment retained')
                elif allow and c['elapsed']/allow>=threshold['amber']:notify(table,r,'amber','Mission allowance nearly consumed')
                if r['status']=='Pending acceptance':notify(table,r,'handoff','Deliverable waiting for acceptance',r['receiver_id'])
                if c['overdue']>=threshold['escalation_days']*86400:
                    for manager in db.execute("SELECT user_id FROM user_roles WHERE role='Manager'"):notify(table,r,'escalation','Overdue mission needs manager review',manager[0])
            if table=='opportunities' and r['stage'] not in ('Closed Lost','Banked / Closed Won'):
                if not r['next_action']:notify(table,r,'next_action','Missing next action')
                if r['updated_at'][:10]<(date.today()-timedelta(days=14)).isoformat():notify(table,r,'stale','Opportunity inactive for 14 days')
            if table=='quotations' and r['status']=='Issued' and not r['accepted_at']:
                if r['follow_up'] and r['follow_up']<=today:notify(table,r,'follow_up','Follow up on issued quotation')
                if r['validity'] and r['validity']<=(date.today()+timedelta(days=3)).isoformat():notify(table,r,'expiry','Quotation expires soon or has expired')
            if table=='approvals' and r['decision']=='Pending' and r['due_date']<=today:notify(table,r,'approval','Technical approval due',r['approver_id'])
            if table=='orders' and r['forecast_delivery'] and r['opening_date'] and r['forecast_delivery']>r['opening_date']:notify(table,r,'delivery','Forecast delivery is later than store opening')
    for h in db.execute('SELECT * FROM holds WHERE end_at IS NULL AND review_date<=?',(today,)):
        m=record(db,'missions',h['mission_id']);notify('missions',m,'hold_review','Approved hold needs review',h['approver'])

def notifications(db,actor):
    out=[]
    for n in db.execute('SELECT * FROM notifications WHERE user_id=? AND active=1 ORDER BY created_at DESC',(actor.id,)):
        if allowed(actor,n['entity']):
            r=record(db,n['entity'],n['record_id'])
            if visible(db,actor,n['entity'],r):out.append(dict(n))
    return out
