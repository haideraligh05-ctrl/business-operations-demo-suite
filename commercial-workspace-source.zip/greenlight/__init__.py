"""Commercial Workspace local prototype."""
