from dataclasses import dataclass
from .models import MODULES, TECH_MODULES, FINANCE_MODULES, MASTER_MODULES

class Forbidden(ValueError):
    pass

@dataclass(frozen=True)
class Actor:
    id: str
    role: str

def allowed(actor, module, write=False):
    if module not in MODULES: return False
    if actor.role=='R&D': return module in TECH_MODULES and (not write or module in {'technical_requests','approvals','samples','missions','documents','activities'})
    if actor.role=='Read only': return not write
    if actor.role in ('Manager','Administrator'): return True
    if module in ('targets','mission_templates'): return not write
    if actor.role=='Sales' and module in FINANCE_MODULES: return not write
    return actor.role in ('Sales','Processor')

def require(actor, roles):
    if actor.role not in roles: raise Forbidden('Your active role is not authorized for this action.')

def visible(db, actor, module, row):
    if not allowed(actor,module): return False
    if actor.role=='R&D':
        if row.get('owner_id')!=actor.id and row.get('receiver_id')!=actor.id and row.get('approver_id')!=actor.id: return False
        if module=='documents':
            if row.get('permission')!='Technical' or row.get('record_type') not in {'technical_requests','approvals','samples','missions'}:return False
            from .db import record
            try:
                if not visible(db,actor,row['record_type'],record(db,row['record_type'],row['record_id'])):return False
            except ValueError:return False
        # Free-form communication can contain commercial information.
        if module=='activities': return row.get('record_type') in {'technical_requests','samples','approvals','missions'}
    return True

def authorize(db, actor, module, row=None, write=False):
    if not allowed(actor,module,write) or (row and not visible(db,actor,module,row)):
        raise Forbidden('This record is outside your role or assigned scope.')

def serialize(actor, module, row):
    # Deny at module boundary, then allow-list fields. No raw database serialization.
    if not allowed(actor,module): raise Forbidden('Access denied')
    keys={'id','title','owner_id','next_action','due_date','blocked','version','created_at','updated_at'}
    keys.update(f.name for f in MODULES[module][1] if not (f.restricted and actor.role in ('R&D','Read only')))
    from .models import EXTRA_SQL
    if module in EXTRA_SQL:
        keys.update(x.strip().split()[0] for x in EXTRA_SQL[module].split(','))
    keys.discard('storage_name')
    if module=='missions':keys.add('approved_due')
    if actor.role=='R&D':
        keys -= {'scope','terms','accepted_evidence','order_id','opportunity_id','rule_snapshot'}
    return {k:v for k,v in row.items() if k in keys}
