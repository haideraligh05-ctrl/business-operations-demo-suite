"""Field dictionary used by the relational migration and validated record forms.

Money is stored in integer minor units, not binary floating point.
"""
from dataclasses import dataclass

@dataclass(frozen=True)
class Field:
    name: str
    label: str
    kind: str = 'text'
    required: bool = False
    choices: tuple = ()
    ref: str = ''
    restricted: bool = False

def F(name, label=None, kind='text', required=False, choices=(), ref='', restricted=False):
    return Field(name, label or name.replace('_',' ').title(), kind, required, tuple(choices), ref, restricted)

STAGES = ('New Enquiry','Qualified','Scope and Costing','Quotation Submitted','Negotiation','Awaiting PO / Advance','Banked / Closed Won','Closed Lost','On Hold')
REASONS = ('Price','Lead time','Specification','Terms','Competitor','Relationship','Project cancellation','Design fit','Other')
ROLES = ('Sales','Processor','R&D','Manager','Administrator','Read only')
EXECUTION = ('Technical Approvals','Production Release','Production','QA','Ready for Shipment','Shipped','Delivered','Operational Completion')
MODULES = {
 'groups': ('Parent groups',[F('country')]),
 'accounts': ('Accounts',[F('parent_id','Parent group',ref='groups'),F('country',required=True),F('company_type',choices=('Operating company','Franchisee','Billing customer')),F('billing_address'),F('team')]),
 'brands': ('Brands',[F('description')]),
 'brand_relationships': ('Brand relationships',[F('account_id',ref='accounts',required=True),F('brand_id',ref='brands',required=True),F('country')]),
 'contacts': ('Contacts',[F('account_id',ref='accounts',required=True),F('email'),F('phone'),F('contact_role'),F('decision_authority'),F('preferred_channel',choices=('Email','Phone','WhatsApp','Meeting')),F('lead_source')]),
 'projects': ('Projects / Rollouts',[F('account_id',ref='accounts',required=True),F('brand_id',ref='brands'),F('country'),F('opening_date',kind='date')]),
 'stores': ('Stores',[F('project_id',ref='projects',required=True),F('account_id','Billing customer',ref='accounts',required=True),F('country'),F('address'),F('opening_date',kind='date')]),
 'products': ('Products',[F('code',required=True),F('description'),F('dimensions'),F('materials'),F('finish'),F('source'),F('cost',kind='money',restricted=True),F('selling_price',kind='money')]),
 'leads': ('Leads',[F('account_id',ref='accounts'),F('contact_id',ref='contacts'),F('source'),F('need'),F('country')]),
 'opportunities': ('Opportunities',[
   F('account_id',ref='accounts',required=True),F('contact_id',ref='contacts'),F('brand_id',ref='brands'),F('project_id',ref='projects'),F('country',required=True),F('team'),F('currency',choices=('USD','AED','SAR','PKR'),required=True),F('value',kind='money'),F('fx_rate',kind='number'),F('fx_source'),F('fx_date',kind='date'),F('probability',kind='number'),F('confidence',choices=('Low','Medium','High')),F('expected_banking',kind='date'),F('original_forecast',kind='date'),F('source'),F('need'),F('buyer'),F('scope'),F('assumptions'),F('technical_queries'),F('cost_request'),F('feedback'),F('decision_process'),F('risks'),F('agreed_scope'),F('confirmation'),F('reason_code',choices=REASONS),F('explanation'),F('competitor'),F('lessons'),F('review_date',kind='date')]),
 'enquiries': ('Enquiries / RFQ',[F('opportunity_id',ref='opportunities',required=True),F('rfq_date',kind='date'),F('customer_deadline',kind='date'),F('store_opening',kind='date'),F('store_id',ref='stores'),F('scope_categories'),F('layout_reference'),F('source_documents'),F('clarifications'),F('promised_response',kind='date')]),
 'boqs': ('BOQ',[F('opportunity_id',ref='opportunities',required=True),F('exclusions'),F('assumptions'),F('missing_drawings')]),
 'boq_lines': ('BOQ lines',[F('boq_id',ref='boqs',required=True),F('product_id',ref='products'),F('code',required=True),F('description'),F('image_reference'),F('dimensions'),F('materials'),F('finish'),F('quantity',kind='number',required=True),F('unit'),F('source'),F('cost',kind='money',restricted=True),F('selling_price',kind='money'),F('oem_option'),F('alternative')]),
 'quotations': ('Quotations / PI',[F('opportunity_id',ref='opportunities',required=True),F('boq_id',ref='boqs'),F('document_type',choices=('Quotation','Proforma Invoice')),F('currency',choices=('USD','AED','SAR','PKR'),required=True),F('scope',required=True),F('quantity',kind='number'),F('unit_price',kind='money'),F('discount',kind='number'),F('freight',kind='money'),F('total',kind='money',required=True),F('cost',kind='money',restricted=True),F('incoterm'),F('validity',kind='date'),F('lead_time_basis'),F('payment_schedule'),F('terms'),F('nonstandard_terms',kind='check'),F('delivery_exception',kind='check'),F('client_document',ref='documents'),F('follow_up',kind='date')]),
 'technical_requests': ('R&D / Technical requests',[F('opportunity_id',ref='opportunities',required=True),F('order_id',ref='orders'),F('brief'),F('request_type',choices=('Drawing','Structure','Quantity','Finish','Fabric','Swatch','Sample')),F('priority',choices=('Normal','High','Urgent')),F('dependencies'),F('material_source',choices=('Client supplied','Internally sourced'))]),
 'approvals': ('Approval items',[F('technical_request_id',ref='technical_requests',required=True),F('order_id',ref='orders'),F('item',required=True),F('item_revision',required=True),F('approver_id',ref='users',required=True),F('requested_date',kind='date'),F('scope_level',choices=('Global','Brand','Country','Store'),required=True),F('brand_id',ref='brands'),F('country'),F('store_id',ref='stores'),F('mandatory',kind='check'),F('comments'),F('evidence')]),
 'samples': ('Samples',[F('technical_request_id',ref='technical_requests',required=True),F('sample_status',choices=('Production','Dispatch','Receipt','Client review','Rework')),F('dispatch_date',kind='date'),F('received_date',kind='date'),F('review_result'),F('material_source',choices=('Client supplied','Internally sourced'))]),
 'orders': ('Orders',[F('opportunity_id',ref='opportunities',required=True),F('quotation_id','Accepted quotation revision',ref='quotations',required=True),F('account_id','Billing customer',ref='accounts',required=True),F('contact_id',ref='contacts'),F('terms'),F('currency',choices=('USD','AED','SAR','PKR'),required=True),F('value',kind='money',required=True),F('advance_required',kind='money',required=True),F('fx_rate',kind='number',required=True),F('fx_source',required=True),F('fx_date',kind='date',required=True),F('factory'),F('delivery_address'),F('opening_date',kind='date'),F('forecast_delivery',kind='date'),F('shipping_days',kind='number'),F('customs_days',kind='number'),F('original_claim_id',ref='claims')]),
 'order_lines': ('Order lines / Batches',[F('order_id',ref='orders',required=True),F('boq_line_id',ref='boq_lines'),F('store_id',ref='stores',required=True),F('product_id',ref='products'),F('quantity',kind='number',required=True),F('unit_price',kind='money'),F('batch'),F('execution',choices=EXECUTION)]),
 'milestones': ('Production / Milestones',[F('order_id',ref='orders',required=True),F('dependency_id',ref='milestones'),F('original_baseline',kind='date',required=True),F('client_requested',kind='date'),F('commitment',kind='date',required=True),F('forecast',kind='date'),F('actual',kind='date'),F('trigger',choices=('Verified advance','Technical approvals')),F('duration_days',kind='number'),F('day_basis',choices=('working','calendar')),F('holidays'),F('factory')]),
 'shipments': ('Shipments / Delivery',[F('order_id',ref='orders',required=True),F('factory'),F('origin'),F('destination'),F('cbm',kind='number'),F('packing'),F('freight_validity',kind='date'),F('freight_charges',kind='money'),F('booking'),F('etd',kind='date'),F('eta',kind='date'),F('clearance'),F('proof_of_delivery'),F('commercial_invoice',ref='documents'),F('packing_list',ref='documents'),F('certificate',ref='documents'),F('original_claim_id',ref='claims')]),
 'shipment_allocations': ('Shipment allocations',[F('shipment_id',ref='shipments',required=True),F('order_line_id',ref='order_lines',required=True),F('quantity',kind='number',required=True)]),
 'invoices': ('Collections / Invoices',[F('order_id',ref='orders',required=True),F('schedule',choices=('Advance','Pre-loading balance','Post-delivery','Retention')),F('due_trigger'),F('currency',choices=('USD','AED','SAR','PKR'),required=True),F('amount',kind='money',required=True),F('credits',kind='money'),F('promised_date',kind='date'),F('dispute'),F('collection_task')]),
 'payments': ('Payments / Receipts',[F('account_id',ref='accounts',required=True),F('currency',choices=('USD','AED','SAR','PKR'),required=True),F('amount',kind='money',required=True),F('receipt_date',kind='date',required=True),F('reference',required=True),F('finance_confirmation',required=True),F('evidence',required=True)]),
 'payment_allocations': ('Receipt allocations',[F('payment_id',ref='payments',required=True),F('order_id',ref='orders',required=True),F('invoice_id',ref='invoices'),F('amount',kind='money',required=True)]),
 'claims': ('Claims / After sales',[F('order_id',ref='orders',required=True),F('order_line_id',ref='order_lines'),F('claim_type',choices=('Damage','Shortage','Installation')),F('photos'),F('cost',kind='money',restricted=True),F('corrective_action'),F('client_acceptance')]),
 'stock': ('Reserved stock',[F('account_id',ref='accounts',required=True),F('product_id',ref='products',required=True),F('quantity',kind='number',required=True),F('location'),F('approval_status',choices=('Pending','Approved')),F('call_off',kind='number')]),
 'documents': ('Documents',[F('record_type',required=True),F('record_id',required=True),F('document_type',choices=('PO','Quotation','Drawing','Finance','Photo','Certificate','Other')),F('permission',choices=('Technical','Commercial','Finance'),required=True),F('source'),F('preview_id',ref='documents')]),
 'activities': ('Activities',[F('record_type',required=True),F('record_id',required=True),F('activity_type',choices=('Call','Meeting','Email attachment','WhatsApp decision','Task','Approval')),F('source',required=True),F('occurred_at',kind='date',required=True),F('notes',required=True),F('evidence')]),
 'mission_templates': ('Mission templates',[F('duration_days',kind='number',required=True),F('day_basis',choices=('working','calendar'),required=True),F('timezone',required=True),F('workweek',required=True),F('holidays'),F('required_inputs'),F('dependencies'),F('checklist',required=True),F('owner_role',choices=ROLES),F('required',kind='check'),F('weight',kind='number'),F('complexity',kind='number')]),
 'missions': ('Missions / Handoffs',[F('opportunity_id',ref='opportunities',required=True),F('template_id',ref='mission_templates',required=True),F('receiver_id',ref='users',required=True),F('dependency_id',ref='missions'),F('inputs_evidence'),F('deliverable'),F('checklist_evidence')]),
 'targets': ('Targets',[F('period_start',kind='date',required=True),F('period_end',kind='date',required=True),F('period_type',choices=('Annual','Quarterly','Monthly')),F('amount',kind='money',required=True),F('country'),F('account_id',ref='accounts'),F('brand_id',ref='brands'),F('project_id',ref='projects'),F('team'),F('currency',choices=('USD',)),F('approved',kind='check')]),
}

TECH_MODULES={'technical_requests','approvals','samples','missions','documents','activities','projects','stores','products','accounts','contacts','brands'}
FINANCE_MODULES={'payments','payment_allocations','invoices','targets'}
MASTER_MODULES={'groups','accounts','brands','brand_relationships','contacts','projects','stores','products','leads','opportunities','enquiries','boqs','boq_lines'}
EXTRA_SQL = {
 'opportunities': "stage TEXT NOT NULL DEFAULT 'New Enquiry', closed_at TEXT, submitted_at TEXT",
 'enquiries': 'submitted_at TEXT',
 'quotations': "family_id TEXT, revision INTEGER NOT NULL DEFAULT 1, status TEXT NOT NULL DEFAULT 'Draft', issued_at TEXT, accepted_at TEXT, accepted_evidence TEXT, exception_approved_by TEXT REFERENCES users(id)",
 'approvals': "decision TEXT NOT NULL DEFAULT 'Pending', decided_at TEXT",
 'orders': "confirmed_at TEXT, confirmation_evidence TEXT, po_id TEXT REFERENCES documents(id), po_valid_at TEXT, execution TEXT NOT NULL DEFAULT 'Technical Approvals', commercial_status TEXT NOT NULL DEFAULT 'Awaiting banking', risk_status TEXT NOT NULL DEFAULT 'On track'",
 'payments': 'verified_at TEXT, verified_by TEXT REFERENCES users(id), reversed_at TEXT',
 'shipments': "status TEXT NOT NULL DEFAULT 'Planned', delivered_at TEXT",
 'documents': 'filename TEXT, storage_name TEXT, document_version INTEGER NOT NULL DEFAULT 1, previous_id TEXT REFERENCES documents(id), uploaded_by TEXT REFERENCES users(id)',
 'missions': "status TEXT NOT NULL DEFAULT 'Upcoming', calendar_snapshot TEXT, rule_snapshot TEXT, assigned_at TEXT, ready_at TEXT, acknowledged_at TEXT, submitted_at TEXT, accepted_at TEXT, completed_at TEXT, original_due TEXT, acceptance_revision INTEGER NOT NULL DEFAULT 0, rejected_count INTEGER NOT NULL DEFAULT 0, skip_reason TEXT, skip_approver TEXT REFERENCES users(id)",
}
