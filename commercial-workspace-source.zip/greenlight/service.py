"""Transactional application service. All mutations pass through this boundary."""
import json
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from datetime import date
from .db import now, uid, insert, record, audit, setting
from .models import MODULES, STAGES, REASONS, EXECUTION
from .security import authorize, require, visible, serialize, Forbidden
from .clocks import deadline, clock, dt

class Conflict(ValueError): pass

def money(value):
    try:
        d=Decimal(str(value or 0))
        if not d.is_finite(): raise ValueError('Amount must be finite')
        return int((d*100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
    except InvalidOperation: raise ValueError('Enter a valid amount')

def need(data,*keys):
    missing=[k.replace('_',' ') for k in keys if data.get(k) is None or str(data.get(k)).strip()=='']
    if missing: raise ValueError('Required: '+', '.join(missing))

def rows(db,actor,table):
    authorize(db,actor,table)
    merged={r[0] for r in db.execute('SELECT source_id FROM merges WHERE entity=?',(table,))}
    return [serialize(actor,table,dict(r)) for r in db.execute(f'SELECT * FROM {table} ORDER BY updated_at DESC') if r['id'] not in merged and visible(db,actor,table,dict(r))]

def get(db,actor,table,id):
    r=record(db,table,id); authorize(db,actor,table,r); return r

def mutate(db,actor,table,r,changes,action,reason=''):
    changes={**changes,'updated_at':now(),'version':r['version']+1}
    n=db.execute(f'UPDATE {table} SET '+','.join(f'{k}=?' for k in changes)+' WHERE id=? AND version=?',[*changes.values(),r['id'],r['version']]).rowcount
    if n!=1: raise Conflict('This record changed. Reload before saving.')
    audit(db,actor.id,actor.role,table,r['id'],action,r,changes,reason)
    return record(db,table,r['id'])

def save(db,actor,table,data,id=None):
    old=get(db,actor,table,id) if id else None
    authorize(db,actor,table,old,True)
    request_id=data.get('request_id')
    if request_id and not id:
        previous=db.execute('SELECT record_id FROM request_keys WHERE actor=? AND entity=? AND request_id=?',(actor.id,table,request_id)).fetchone()
        if previous:return get(db,actor,table,previous[0])
    if old and int(data.get('version',0))!=old['version']: raise Conflict('This record changed. Reload before saving.')
    if old and (table in ('payment_allocations','shipment_allocations','documents') or table=='payments' and old['verified_at'] or table=='quotations' and old['status']=='Issued' or table=='orders' and db.execute('SELECT 1 FROM bank_events WHERE order_id=?',(id,)).fetchone()):
        raise ValueError('Controlled record: use revision, reversal or adjustment actions.')
    if old and table=='milestones' and any(data.get(k,old.get(k))!=old.get(k) for k in ('original_baseline','commitment')):
        require(actor,('Manager','Administrator')); need(data,'reason')
        if data.get('original_baseline',old['original_baseline'])!=old['original_baseline']:raise ValueError('Original baseline is immutable')
    if old and table=='approvals':
        controlled=('order_id','technical_request_id','mandatory','scope_level','approver_id','store_id','country','brand_id')
        if any(k in data and str(data[k] or '')!=str(old.get(k) or '') for k in controlled):require(actor,('Manager','Administrator'))
    if old and table=='missions':
        if any(k in data and str(data[k] or '')!=str(old.get(k) or '') for k in ('opportunity_id','template_id','dependency_id','receiver_id','owner_id')):require(actor,('Manager','Administrator'))
    vals={k:str(data.get(k,old.get(k,'') if old else '') or '').strip() for k in ('title','next_action','due_date','blocked')}
    vals['owner_id']=data.get('owner_id') or (old or {}).get('owner_id') or actor.id
    if table=='targets' and not data.get('owner_id'):vals['owner_id']=None
    need(vals,'title','next_action','due_date')
    if table!='targets':need(vals,'owner_id')
    date.fromisoformat(vals['due_date'])
    for f in MODULES[table][1]:
        if f.restricted and actor.role in ('R&D','Read only'):
            if f.name in data: raise Forbidden('Restricted field')
            continue
        if old and f.name not in data:
            vals[f.name]=old.get(f.name)
            continue
        v=data.get(f.name)
        if f.required and (v is None or str(v).strip()==''): raise ValueError(f'{f.label} is required')
        if v is None or v=='': v=None
        elif f.kind=='money': v=money(v)
        elif f.kind=='number':
            v=float(v)
            if not Decimal(str(v)).is_finite():raise ValueError('Number must be finite')
        elif f.kind=='check': v=int(str(v).lower() in ('1','true','on'))
        elif f.kind=='date': date.fromisoformat(v)
        if f.choices and v is not None and v not in f.choices:raise ValueError(f'Invalid {f.label}')
        if f.ref and v and not (old and v==old.get(f.name)):
            get(db,actor,f.ref,v) if f.ref!='users' else record(db,'users',v)
        vals[f.name]=v
    if table in ('activities','documents'):
        parent=get(db,actor,vals['record_type'],vals['record_id'])
        if actor.role=='R&D' and vals['record_type'] not in ('technical_requests','approvals','samples','missions'):raise Forbidden('Technical evidence must link to assigned technical work')
    if table=='documents' and actor.role=='R&D' and vals['permission']!='Technical':raise Forbidden('Technical documents only')
    if table=='quotations' and old:
        vals['exception_approved_by']=None
    if table=='approvals' and not old and actor.role not in ('Manager','Administrator'):
        # Technical staff may draft items, but cannot alter the release gate's applicability.
        vals['mandatory']=1
    if table=='mission_templates':
        from zoneinfo import ZoneInfo
        ZoneInfo(vals['timezone'])
        if not vals['workweek'] or any(x not in '0123456' for x in vals['workweek'].split(',')):raise ValueError('Workweek uses comma-separated 0–6 weekdays')
        if vals['complexity'] not in (1,2,3) or vals['duration_days']<=0:raise ValueError('Positive duration and complexity 1, 2 or 3 required')
    if table=='opportunities':
        if vals.get('fx_rate') is None:vals['fx_rate']=1
        if vals.get('probability') is None:vals['probability']=0
        if not 0<=vals['probability']<=100:raise ValueError('Probability must be 0–100')
    if table in ('orders','opportunities') and vals.get('fx_rate',1)<=0:raise ValueError('FX rate must be positive')
    if table=='order_lines':
        store=record(db,'stores',vals['store_id']);order=record(db,'orders',vals['order_id'])
        if store['account_id']!=order['account_id']:raise ValueError('Store billing customer must match order')
        if old and db.execute('SELECT 1 FROM shipment_allocations WHERE order_line_id=?',(id,)).fetchone():raise ValueError('Allocated order lines require a controlled scope change')
    for k in ('value','amount','quantity','advance_required','total','cost','selling_price','credits','call_off'):
        if vals.get(k) is not None and vals[k]<0:raise ValueError(k+' cannot be negative')
    if table=='stock' and (vals.get('call_off') or 0)>vals['quantity']:raise ValueError('Call-off exceeds reserved quantity')
    if table=='orders':
        q=get(db,actor,'quotations',vals['quotation_id']); o=get(db,actor,'opportunities',vals['opportunity_id'])
        if not q['accepted_at'] or q['opportunity_id']!=o['id'] or q['currency']!=vals['currency']:raise ValueError('Select an accepted revision for this opportunity and currency')
        awarded=db.execute('SELECT COALESCE(SUM(value),0) FROM orders WHERE opportunity_id=? AND id!=?',(o['id'],id or '')).fetchone()[0]
        if vals['currency']!=o['currency'] or awarded+vals['value']>o['value']:raise ValueError('Award exceeds opportunity scope or uses a different currency')
        if vals['advance_required']>vals['value']:raise ValueError('Advance exceeds order value')
        if vals['advance_required']<=0:raise ValueError('A positive required advance is mandatory in this prototype; zero-advance policy needs business sign-off')
    if table=='payment_allocations':
        p=get(db,actor,'payments',vals['payment_id']); o=get(db,actor,'orders',vals['order_id'])
        spent=db.execute('SELECT COALESCE(SUM(amount),0) FROM payment_allocations WHERE payment_id=?',(p['id'],)).fetchone()[0]
        if vals['amount']<=0 or p['reversed_at'] or spent+vals['amount']>p['amount']:raise ValueError('Receipt has insufficient unallocated funds or amount is not positive')
        if p['currency']!=o['currency'] or p['account_id']!=o['account_id']:raise ValueError('Receipt customer and currency must match order')
        if vals.get('invoice_id') and record(db,'invoices',vals['invoice_id'])['order_id']!=o['id']:raise ValueError('Invoice must belong to order')
    if table=='invoices':
        if vals['currency']!=record(db,'orders',vals['order_id'])['currency']:raise ValueError('Invoice currency must match order')
        if (vals.get('credits') or 0)>vals['amount']:raise ValueError('Credits cannot exceed invoice amount')
        if old and any(vals[k]!=old.get(k) for k in ('order_id','currency','amount','credits')):require(actor,('Manager','Administrator'))
    if table=='shipment_allocations':
        s=get(db,actor,'shipments',vals['shipment_id']); line=get(db,actor,'order_lines',vals['order_line_id'])
        allocated=db.execute('SELECT COALESCE(SUM(quantity),0) FROM shipment_allocations WHERE order_line_id=?',(line['id'],)).fetchone()[0]
        if s['order_id']!=line['order_id'] or vals['quantity']<=0 or allocated+vals['quantity']>line['quantity']:raise ValueError('Shipment allocation exceeds available line quantity or belongs to another order')
    if table=='missions' and old and old['ready_at']:
        if vals['template_id']!=old['template_id'] or vals['dependency_id']!=old['dependency_id']:raise ValueError('Started mission calendar and dependency are locked')
    if old:
        result=mutate(db,actor,table,old,vals,'update',data.get('reason',''))
        if table=='approvals' and vals['item_revision']!=old['item_revision']:
            result=mutate(db,actor,table,result,{'decision':'Pending','decided_at':None,'evidence':None},'invalidate approval','Specification revision changed')
    else:
        result={**vals,'id':uid(table),'created_at':now(),'updated_at':now(),'version':1}
        insert(db,table,result); audit(db,actor.id,actor.role,table,result['id'],'create',None,result)
        result=record(db,table,result['id'])
        if request_id:db.execute('INSERT INTO request_keys VALUES(?,?,?,?)',(actor.id,table,request_id,result['id']))
    if table=='payment_allocations':bank(db,actor,vals['order_id'])
    return result

def cash(db,order_id):
    return db.execute('SELECT COALESCE(SUM(a.amount),0) FROM payment_allocations a JOIN payments p ON p.id=a.payment_id WHERE a.order_id=? AND p.verified_at IS NOT NULL AND p.reversed_at IS NULL',(order_id,)).fetchone()[0]

def bank(db,actor,id):
    o=record(db,'orders',id)
    existing=db.execute('SELECT * FROM bank_events WHERE order_id=?',(id,)).fetchone()
    if existing:return dict(existing)
    if not o['confirmed_at'] or not o['po_valid_at'] or not o['po_id'] or o['advance_required']<=0 or cash(db,id)<o['advance_required']:return None
    final=db.execute('SELECT MAX(MAX(p.verified_at,a.created_at)) FROM payments p JOIN payment_allocations a ON p.id=a.payment_id WHERE a.order_id=? AND p.verified_at IS NOT NULL AND p.reversed_at IS NULL',(id,)).fetchone()[0]
    b=dict(id=uid('BANK'),order_id=id,value=o['value'],usd_value=int(Decimal(o['value'])*Decimal(str(o['fx_rate']))),fx_rate=str(o['fx_rate']),fx_source=o['fx_source'],fx_date=o['fx_date'],effective_at=max(o['confirmed_at'],o['po_valid_at'],final or o['confirmed_at']),verified_at=now(),actor=actor.id)
    insert(db,'bank_events',b); mutate(db,actor,'orders',o,{'commercial_status':'Banked'},'bank', 'All three banking conditions verified')
    audit(db,actor.id,actor.role,'orders',id,'bank event',None,b)
    return b

def net(db,id):
    b=db.execute('SELECT value FROM bank_events WHERE order_id=?',(id,)).fetchone()
    return (b[0] if b else 0)+db.execute('SELECT COALESCE(SUM(amount),0) FROM adjustments WHERE order_id=?',(id,)).fetchone()[0]

def blockers(db,id,gate):
    o=record(db,'orders',id); reasons=[]
    if not db.execute('SELECT 1 FROM bank_events WHERE order_id=?',(id,)).fetchone():reasons.append('Order is not banked')
    if net(db,id)<=0:reasons.append('No active awarded value')
    if cash(db,id)<o['advance_required']:reasons.append('Verified advance is insufficient')
    if db.execute("SELECT 1 FROM approvals WHERE order_id=? AND mandatory=1 AND (decision!='Approved' OR scope_level='Global')",(id,)).fetchone():reasons.append('Mandatory local technical approval pending')
    if gate=='loading':
        for inv in db.execute("SELECT * FROM invoices WHERE order_id=? AND schedule='Pre-loading balance'",(id,)):
            paid=db.execute('SELECT COALESCE(SUM(a.amount),0) FROM payment_allocations a JOIN payments p ON p.id=a.payment_id WHERE a.invoice_id=? AND p.verified_at IS NOT NULL AND p.reversed_at IS NULL',(inv['id'],)).fetchone()[0]
            if inv['amount']-(inv['credits'] or 0)>paid:reasons.append('Pre-loading balance outstanding')
    return reasons

def start_mission(db,actor,m):
    if m['ready_at']:return m
    need(m,'inputs_evidence','owner_id')
    if m['dependency_id'] and record(db,'missions',m['dependency_id'])['status'] not in ('Accepted','Skipped'):raise ValueError('Dependency has not been accepted')
    t=record(db,'mission_templates',m['template_id']); at=now()
    rule=setting(db,'scoring',{'version':1,'accepted':10,'on_time':2,'badge':5,'weekly_goal':10})
    return mutate(db,actor,'missions',m,dict(status='Active',calendar_snapshot=json.dumps(t),rule_snapshot=json.dumps(rule),assigned_at=at,ready_at=at,original_due=deadline(at,t['duration_days']*86400,t)),'ready and assigned')

def submit_enquiry(db,actor,o):
    need(o,'account_id','source','need','country','owner_id','next_action','due_date')
    if db.execute('SELECT 1 FROM enquiry_cycles WHERE opportunity_id=? AND ended_at IS NULL',(o['id'],)).fetchone():return
    previous=db.execute('SELECT id FROM enquiry_cycles WHERE opportunity_id=? ORDER BY started_at DESC LIMIT 1',(o['id'],)).fetchone()
    insert(db,'enquiry_cycles',dict(id=uid('CYCLE'),opportunity_id=o['id'],previous_id=previous[0] if previous else None,started_at=now()))
    mutate(db,actor,'opportunities',o,{'submitted_at':now()},'submit enquiry')
    if not previous:
        last=None
        for t in db.execute('SELECT * FROM mission_templates ORDER BY rowid'):
            assigned=db.execute('SELECT user_id FROM user_roles WHERE role=? ORDER BY user_id LIMIT 1',(t['owner_role'],)).fetchone()
            m=dict(id=uid('MIS'),title=t['title'],owner_id=assigned[0] if assigned else o['owner_id'],receiver_id=actor.id,next_action='Provide inputs, then start mission',due_date=o['due_date'],blocked='',version=1,created_at=now(),updated_at=now(),opportunity_id=o['id'],template_id=t['id'],dependency_id=last,inputs_evidence='Submitted enquiry scope: '+o['need'] if last is None else None)
            insert(db,'missions',m)
            if last is None:start_mission(db,actor,record(db,'missions',m['id']))
            last=m['id']

def action(db,actor,table,id,name,data):
    r=get(db,actor,table,id); authorize(db,actor,table,r,True)
    if name not in ('accept','bank','submit_enquiry') and int(data.get('version',0))!=r['version']:raise Conflict('Record changed. Reload and retry.')
    at=now()
    if name=='merge' and table in ('accounts','contacts'):
        require(actor,('Manager','Administrator'));need(data,'target_id','reason','evidence')
        target=get(db,actor,table,data['target_id'])
        if target['id']==id:raise ValueError('Select a different surviving record')
        if db.execute('SELECT 1 FROM merges WHERE entity=? AND source_id=?',(table,id)).fetchone():return target['id']
        for child,(_,fields) in MODULES.items():
            for f in fields:
                if f.ref==table:
                    for linked in db.execute(f'SELECT * FROM {child} WHERE {f.name}=?',(id,)).fetchall():
                        mutate(db,actor,child,dict(linked),{f.name:target['id']},'relink controlled merge',data['reason'])
        for child in ('documents','activities'):
            db.execute(f'UPDATE {child} SET record_id=? WHERE record_type=? AND record_id=?',(target['id'],table,id))
        insert(db,'merges',dict(entity=table,source_id=id,target_id=target['id'],actor=actor.id,occurred_at=at,reason=data['reason'],evidence=data['evidence']))
        audit(db,actor.id,actor.role,table,id,'controlled merge',r,target,data['reason']);return target['id']
    if table=='opportunities':
        if name=='submit_enquiry':submit_enquiry(db,actor,r)
        elif name=='stage':
            stage=data.get('stage')
            if stage not in STAGES:raise ValueError('Invalid stage')
            requirements={'Qualified':('buyer','scope','value','expected_banking'),'Scope and Costing':('assumptions','technical_queries','cost_request'),'Negotiation':('feedback','decision_process','risks','next_action'),'Awaiting PO / Advance':('agreed_scope','confirmation')}
            need(r,'account_id','source','need','country','owner_id','next_action','due_date')
            if stage not in ('Closed Lost','On Hold'):
                for required_stage,fields in requirements.items():
                    if STAGES.index(required_stage)<=STAGES.index(stage):need(r,*fields)
            if stage in ('Quotation Submitted','Negotiation','Awaiting PO / Advance','Banked / Closed Won') and not db.execute("SELECT 1 FROM quotations WHERE opportunity_id=? AND status='Issued'",(id,)).fetchone():raise ValueError('Issue a complete quotation revision first')
            if stage=='Banked / Closed Won':
                awarded=db.execute('SELECT COALESCE(SUM(b.value),0) FROM bank_events b JOIN orders o ON o.id=b.order_id WHERE o.opportunity_id=?',(id,)).fetchone()[0]
                if awarded<r['value']:raise ValueError('Unawarded scope remains open. Bank the entire scope before closing won.')
            if stage in ('Closed Lost','Banked / Closed Won'):
                need(data,'reason_code','explanation')
                if data['reason_code'] not in REASONS:raise ValueError('Select a controlled reason')
            change={'stage':stage}
            if stage in ('Closed Lost','Banked / Closed Won'):
                change.update(closed_at=at,reason_code=data['reason_code'],explanation=data['explanation']); db.execute('UPDATE enquiry_cycles SET ended_at=? WHERE opportunity_id=? AND ended_at IS NULL',(at,id))
            elif stage=='On Hold':need(data,'reason','review_date'); date.fromisoformat(data['review_date']); change.update(explanation=data['reason'],review_date=data['review_date'])
            elif r['closed_at']:change['closed_at']=None; submit_enquiry(db,actor,r); r=record(db,table,id)
            mutate(db,actor,table,r,change,'stage transition',data.get('explanation',''))
        else:raise ValueError('Unknown opportunity action')
    elif table=='quotations':
        if name=='revise':
            require(actor,('Processor','Manager','Administrator','Sales'))
            if r['status']!='Issued':raise ValueError('Only issued quotations need a revision')
            family=r['family_id'] or id
            revision=db.execute('SELECT MAX(revision) FROM quotations WHERE family_id=? OR id=?',(family,family)).fetchone()[0]+1
            copy={**r,'id':uid('QUO'),'family_id':family,'revision':revision,'status':'Draft','issued_at':None,'accepted_at':None,'accepted_evidence':None,'exception_approved_by':None,'version':1,'created_at':at,'updated_at':at}
            insert(db,table,copy);audit(db,actor.id,actor.role,table,copy['id'],'new revision',r,copy); return copy['id']
        elif name=='approve_exception':
            require(actor,('Manager','Administrator'));need(data,'reason','evidence');mutate(db,actor,table,r,{'exception_approved_by':actor.id},'commercial exception',data['reason']+'; '+data['evidence'])
        elif name=='issue':
            if r['status']=='Issued':return id
            need(r,'terms','validity','follow_up','client_document','payment_schedule','lead_time_basis','incoterm','scope','total')
            doc=get(db,actor,'documents',r['client_document'])
            if not doc['storage_name']:raise ValueError('Upload the exact client-issued file before issuing')
            thresholds=setting(db,'commercial',{'max_discount':10,'minimum_margin':15})
            margin=(r['total']-(r['cost'] or 0))/r['total']*100 if r['total'] else 0
            if ((r['discount'] or 0)>thresholds['max_discount'] or margin<thresholds['minimum_margin'] or r['nonstandard_terms'] or r['delivery_exception']) and not r['exception_approved_by']:raise ValueError('Manager approval required for commercial exception')
            mutate(db,actor,table,r,{'status':'Issued','issued_at':at,'family_id':r['family_id'] or id},'issue revision')
        elif name=='accept':
            if r['status']!='Issued':raise ValueError('Only an issued revision can be accepted')
            if not r['accepted_at']:
                need(data,'evidence');mutate(db,actor,table,r,{'accepted_at':at,'accepted_evidence':data['evidence']},'client acceptance',f"Revision {r['revision']}; scope {r['scope']}; price {r['total']}")
        elif name=='convert_order':
            if not r['accepted_at']:raise ValueError('Record client acceptance before converting scope')
            need(data,'amount','advance_required')
            o=get(db,actor,'opportunities',r['opportunity_id'])
            values=dict(title=r['title']+' · awarded scope',owner_id=r['owner_id'],next_action='Confirm order, attach PO and verify advance',due_date=r['due_date'],opportunity_id=o['id'],quotation_id=id,account_id=o['account_id'],contact_id=o['contact_id'],terms=r['terms'],currency=r['currency'],value=data['amount'],advance_required=data['advance_required'],fx_rate=o['fx_rate'],fx_source=o['fx_source'],fx_date=o['fx_date'],request_id=data.get('request_id'))
            created=save(db,actor,'orders',values)
            return 'orders:'+created['id']
        else:raise ValueError('Unknown quotation action')
    elif table=='orders':
        if name=='reforecast':
            require(actor,('Processor','Manager','Administrator'))
            from .execution import forecast
            result=forecast(db,id)
            mutate(db,actor,table,r,{'forecast_delivery':result['forecast'],'risk_status':result['risk']},'recalculate delivery risk','Pending triggers: '+', '.join(result['pending']))
        elif name=='confirm':
            require(actor,('Processor','Manager','Administrator'));need(data,'evidence');mutate(db,actor,table,r,{'confirmed_at':at,'confirmation_evidence':data['evidence']},'confirmed order');bank(db,actor,id)
        elif name=='validate_po':
            require(actor,('Processor','Manager','Administrator'));need(data,'po_id')
            doc=get(db,actor,'documents',data['po_id'])
            if doc['document_type']!='PO' or doc['record_type']!='orders' or doc['record_id']!=id or not doc['storage_name']:raise ValueError('Upload a PO attached to this order first')
            mutate(db,actor,table,r,{'po_id':doc['id'],'po_valid_at':at},'validate PO');bank(db,actor,id)
        elif name=='bank':bank(db,actor,id)
        elif name=='adjust':
            require(actor,('Manager','Administrator'));need(data,'reason','evidence','amount','kind')
            if data['kind'] not in ('Cancellation','Refund','Credit','Value change','FX correction','Receipt reversal'):raise ValueError('Invalid adjustment kind')
            b=db.execute('SELECT * FROM bank_events WHERE order_id=?',(id,)).fetchone()
            if not b:raise ValueError('Order has not banked')
            amount=money(data['amount'])
            if net(db,id)+amount<0:raise ValueError('Adjustment exceeds net banked value')
            key=data.get('request_id') or uid('ADJ')
            if not db.execute('SELECT 1 FROM adjustments WHERE id=?',(key,)).fetchone():
                a=dict(id=key,order_id=id,amount=amount,usd_amount=int(Decimal(amount)*Decimal(b['fx_rate'])),kind=data['kind'],reason=data['reason'],evidence=data['evidence'],actor=actor.id,effective_at=at,created_at=at)
                insert(db,'adjustments',a);audit(db,actor.id,actor.role,table,id,'adjustment',None,a)
        elif name=='execute':
            require(actor,('Processor','Manager','Administrator'));need(data,'execution','evidence')
            stage=data['execution']
            if stage not in ('Production','QA','Ready for Shipment','Shipped','Operational Completion'):raise ValueError('Use release or delivery controls for this stage')
            gate='loading' if stage in ('Ready for Shipment','Shipped','Operational Completion') else 'production'
            reasons=blockers(db,id,gate)
            if reasons:raise ValueError('Blocked: '+', '.join(reasons))
            if stage=='Operational Completion':
                if r['execution']!='Delivered' or cash(db,id)<net(db,id) or db.execute("SELECT 1 FROM claims WHERE order_id=? AND (client_acceptance IS NULL OR client_acceptance='' OR client_acceptance='Pending')",(id,)).fetchone():raise ValueError('Delivery, collections and claim acceptance must be complete')
            mutate(db,actor,table,r,{'execution':stage},'execution update',data['evidence'])
        elif name in ('release','load'):
            require(actor,('Processor','Manager','Administrator'));gate='production' if name=='release' else 'loading'; reasons=blockers(db,id,gate)
            exc=db.execute('SELECT 1 FROM exceptions WHERE order_id=? AND gate=?',(id,gate)).fetchone()
            if reasons and (not exc or 'Order is not banked' in reasons or 'No active awarded value' in reasons):raise ValueError('Blocked: '+', '.join(reasons))
            mutate(db,actor,table,r,{'execution':'Production' if name=='release' else 'Ready for Shipment'},gate+' release')
        elif name=='exception':
            require(actor,('Manager','Administrator'));need(data,'reason','evidence','impact','gate')
            if data['gate'] not in ('production','loading'):raise ValueError('Invalid gate')
            e=dict(id=uid('EXC'),order_id=id,gate=data['gate'],reason=data['reason'],evidence=data['evidence'],impact=data['impact'],approver=actor.id,created_at=at)
            insert(db,'exceptions',e);audit(db,actor.id,actor.role,table,id,'release exception',None,e)
        else:raise ValueError('Unknown order action')
    elif table=='payments':
        require(actor,('Manager','Administrator'))
        if name=='verify':
            if r['reversed_at']:raise ValueError('Reversed receipt cannot be verified')
            need(r,'finance_confirmation','evidence','reference','receipt_date')
            if not r['verified_at']:mutate(db,actor,table,r,{'verified_at':at,'verified_by':actor.id},'finance verification')
            for a in db.execute('SELECT order_id FROM payment_allocations WHERE payment_id=?',(id,)):bank(db,actor,a[0])
        elif name=='reverse':
            need(data,'reason')
            if not r['reversed_at']:
                mutate(db,actor,table,r,{'reversed_at':at},'receipt reversal',data['reason'])
                for a in db.execute('SELECT order_id FROM payment_allocations WHERE payment_id=?',(id,)):
                    o=record(db,'orders',a[0]);mutate(db,actor,'orders',o,{'risk_status':'Blocked','blocked':'Receipt reversed; verify advance and review banking adjustment'},'receipt reversal hold',data['reason'])
        else:raise ValueError('Unknown payment action')
    elif table=='approvals':
        if name!='decide':raise ValueError('Unknown approval action')
        if r['approver_id']!=actor.id and actor.role not in ('Manager','Administrator'):raise Forbidden('Only the assigned approver may decide')
        need(data,'evidence','decision')
        if data['decision'] not in ('Approved','Rejected'):raise ValueError('Invalid decision')
        mutate(db,actor,table,r,{'decision':data['decision'],'evidence':data['evidence'],'comments':data.get('reason',''),'decided_at':at},'technical decision')
    elif table=='missions':
        if actor.id not in (r['owner_id'],r['receiver_id']) and actor.role not in ('Manager','Administrator'):raise Forbidden('Only mission participants can act')
        if name=='ready':start_mission(db,actor,r)
        elif name=='acknowledge':
            if not r['ready_at']:raise ValueError('Mission must be ready and assigned')
            if not r['acknowledged_at']:mutate(db,actor,table,r,{'acknowledged_at':at},'acknowledge')
        elif name=='submit':
            if r['status'] not in ('Active','Rework'):raise ValueError('Only active work may be submitted')
            need(data,'evidence','checklist')
            if data['checklist']!='complete':raise ValueError('Confirm the complete acceptance checklist')
            rev=r['acceptance_revision']+1
            insert(db,'handoffs',dict(id=uid('HAND'),mission_id=id,revision=rev,sender=actor.id,receiver=r['receiver_id'],submitted_at=at,evidence=data['evidence']))
            mutate(db,actor,table,r,{'status':'Pending acceptance','submitted_at':at,'acceptance_revision':rev,'deliverable':data['evidence'],'checklist_evidence':data['checklist']},'submit handoff')
        elif name in ('accept','reject'):
            if r['receiver_id']!=actor.id:raise Forbidden('Only the designated receiver may accept or reject')
            if name=='accept' and r['status']=='Accepted':return id
            if r['status']!='Pending acceptance':raise ValueError('No pending handoff')
            h=db.execute('SELECT * FROM handoffs WHERE mission_id=? AND revision=?',(id,r['acceptance_revision'])).fetchone()
            if name=='reject':need(data,'reason')
            db.execute('UPDATE handoffs SET decision=?,decided_at=?,reason=? WHERE id=?',('Accepted' if name=='accept' else 'Rejected',at,data.get('reason',''),h['id']))
            if name=='accept':
                cal=json.loads(r['calendar_snapshot']);rule=json.loads(r['rule_snapshot']);c=clock(db,r,at)
                points=(rule['accepted']+(rule['on_time'] if dt(at)<=dt(r.get('approved_due') or r['original_due']) else 0))*cal['complexity']
                db.execute('INSERT OR IGNORE INTO reward_ledger(id,mission_id,handoff_id,actor,rule_version,points,kind,created_at,reason) VALUES(?,?,?,?,?,?,?,?,?)',(uid('RWD'),id,h['id'],r['owner_id'],rule['version'],points,'Award',at,'Accepted deliverable'))
                mutate(db,actor,table,r,{'status':'Accepted','accepted_at':at,'completed_at':at},'accepted handoff')
                db.execute('UPDATE holds SET end_at=? WHERE mission_id=? AND end_at IS NULL',(at,id))
                for child in db.execute("SELECT * FROM missions WHERE dependency_id=? AND status='Upcoming'",(id,)).fetchall():
                    if child['inputs_evidence']:start_mission(db,actor,dict(child))
            else:mutate(db,actor,table,r,{'status':'Rework','rejected_count':r['rejected_count']+1},'rejected handoff',data['reason'])
        elif name=='hold':
            require(actor,('Manager','Administrator'));need(data,'reason','evidence','review_date','kind');date.fromisoformat(data['review_date'])
            if not r['ready_at'] or r['status'] in ('Accepted','Skipped'):raise ValueError('Only running missions may be held')
            if data['kind'] not in ('Client waiting','Supplier waiting','Internal work'):raise ValueError('Invalid hold type')
            insert(db,'holds',dict(id=uid('HOLD'),mission_id=id,kind=data['kind'],reason=data['reason'],evidence=data['evidence'],approver=actor.id,start_at=at,review_date=data['review_date']))
            audit(db,actor.id,actor.role,table,id,'approved hold',None,data)
        elif name=='resume':
            require(actor,('Manager','Administrator'));db.execute('UPDATE holds SET end_at=? WHERE mission_id=? AND end_at IS NULL',(at,id));audit(db,actor.id,actor.role,table,id,'end hold',None,{'end':at})
        elif name=='skip':
            require(actor,('Manager','Administrator'));need(data,'reason','evidence')
            if r['status'] in ('Accepted','Skipped'):raise ValueError('Completed work cannot be skipped')
            mutate(db,actor,table,r,{'status':'Skipped','skip_reason':data['reason'],'skip_approver':actor.id},'approved skip',data['evidence'])
        elif name=='reverse_reward':
            require(actor,('Manager','Administrator'));need(data,'reason')
            award=db.execute("SELECT * FROM reward_ledger WHERE mission_id=? AND kind='Award'",(id,)).fetchone()
            if not award:raise ValueError('No reward to reverse')
            db.execute('INSERT OR IGNORE INTO reward_ledger VALUES(?,?,?,?,?,?,?,?,?)',(uid('REV'),id,award['handoff_id'],award['actor'],award['rule_version'],-award['points'],'Reversal',at,data['reason']))
            audit(db,actor.id,actor.role,table,id,'reward reversal',None,data)
        elif name=='scope_change':
            require(actor,('Manager','Administrator'));need(data,'reason','evidence','due_date')
            date.fromisoformat(data['due_date'])
            if r['status'] in ('Accepted','Skipped'):raise ValueError('Completed work cannot change its commitment')
            mutate(db,actor,table,r,{'due_date':data['due_date'],'approved_due':data['due_date']+'T23:59:59+00:00'},'approved scope change',data['reason']+'; '+data['evidence'])
        else:raise ValueError('Unknown mission action')
        insert(db,'timer_events',dict(id=uid('TMR'),mission_id=id,event=name,occurred_at=at,actor=actor.id,details=json.dumps(data)))
    elif table=='shipments' and name=='deliver':
        require(actor,('Processor','Manager','Administrator'));need(data,'evidence')
        if not db.execute('SELECT 1 FROM shipment_allocations WHERE shipment_id=?',(id,)).fetchone():raise ValueError('Allocate quantities before delivery')
        mutate(db,actor,table,r,{'status':'Delivered','delivered_at':at,'proof_of_delivery':data['evidence']},'delivery')
        left=db.execute("SELECT SUM(l.quantity-COALESCE((SELECT SUM(a.quantity) FROM shipment_allocations a JOIN shipments s ON s.id=a.shipment_id WHERE a.order_line_id=l.id AND s.status='Delivered'),0)) FROM order_lines l WHERE l.order_id=?",(r['order_id'],)).fetchone()[0]
        if left==0:
            o=record(db,'orders',r['order_id']);mutate(db,actor,'orders',o,{'execution':'Delivered'},'all quantities delivered')
    else:raise ValueError('Unknown action')
    return id
