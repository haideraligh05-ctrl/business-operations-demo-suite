# Commercial Approval & Order Workspace

Runnable Flask and SQLite edition of the Aligh Nexus commercial workflow prototype. Includes opportunity tracking, technical approvals, order processing, delivery records, reporting, and synthetic seed data.

## Start locally

Use Python 3.10 or later in an isolated virtual environment.

```sh
python -m pip install -r requirements.txt
python run.py init --demo
python run.py serve
```

Open http://127.0.0.1:5000 and use an account from the locally generated `DEMO_CREDENTIALS.md`. The server binds to localhost. Use the seeded records to explore the workflow.

```sh
python -m unittest discover -s tests -v
```

[Portfolio case study](https://github.com/haideraligh05-ctrl/professional-portfolio/blob/main/commercial-workflow.md)
