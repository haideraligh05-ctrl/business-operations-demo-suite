import csv, io, json, sqlite3, tempfile, unittest
from pathlib import Path
from datetime import date, timedelta
from greenlight.app import create_app
from greenlight.db import connect, transaction, record, insert, now, uid
from greenlight.seed import seed
from greenlight.service import action, save, bank, cash, net, blockers, start_mission, Conflict
from greenlight.security import Actor, Forbidden
from greenlight.clocks import eligible, clock, deadline
from greenlight.reporting import metrics, automation
from greenlight.imports import preview
from greenlight.models import MODULES

class Acceptance(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base=tempfile.TemporaryDirectory();cls.root=Path(cls.base.name)
        app=create_app({'DATABASE':str(cls.root/'base.db'),'UPLOAD_FOLDER':str(cls.root/'uploads'),'TESTING':True})
        db=connect(cls.root/'base.db')
        with transaction(db):seed(db,cls.root/'uploads',password='test-only-generated-fixture')
        db.close()
    @classmethod
    def tearDownClass(cls):cls.base.cleanup()
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=Path(self.tmp.name)/'test.db'
        src=sqlite3.connect(self.root/'base.db');dst=sqlite3.connect(self.path);src.backup(dst);src.close();dst.close()
        self.app=create_app({'DATABASE':str(self.path),'UPLOAD_FOLDER':str(self.root/'uploads'),'TESTING':True});self.db=connect(self.path);self.actor=Actor('qazi','Manager');self.client=self.app.test_client()
        self.login()
    def tearDown(self):self.db.close();self.tmp.cleanup()
    def login(self,user='qazi',role='Manager'):
        with self.client.session_transaction() as s:s['user_id']=user;s['role']=role
    def act(self,table,id,name,data=None,actor=None):
        with transaction(self.db):return action(self.db,actor or self.actor,table,id,name,{'version':record(self.db,table,id)['version'],**(data or {})})
    def fresh_order(self):
        # Use existing 60k unawarded draft and expand parent scope for exact A01 fixture.
        self.db.execute("UPDATE orders SET value=10000000,advance_required=5000000,confirmed_at=?,confirmation_evidence='confirmed',po_id='PO-01',po_valid_at=? WHERE id='ORD-02'",(now(),now()))
        self.db.execute("UPDATE opportunities SET value=20000000 WHERE id='OPP-01'")
        base=dict(record(self.db,'payments','PAY-01'));base.update(id='TEST-PAY',amount=5000000,reference='TEST-50000',verified_at=None,verified_by=None);insert(self.db,'payments',base)
        base=dict(record(self.db,'payment_allocations','ALLOC-1'));base.update(id='TEST-ALLOC',payment_id='TEST-PAY',order_id='ORD-02',invoice_id=None,amount=5000000);insert(self.db,'payment_allocations',base)
    def test_A01_banks_full_value_once_only_after_verified_advance(self):
        self.fresh_order()
        with transaction(self.db):self.assertIsNone(bank(self.db,self.actor,'ORD-02'))
        self.assertEqual(cash(self.db,'ORD-02'),0)
        self.act('payments','TEST-PAY','verify')
        self.act('orders','ORD-02','bank');self.act('orders','ORD-02','bank')
        self.assertEqual(net(self.db,'ORD-02'),10000000);self.assertEqual(cash(self.db,'ORD-02'),5000000)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM bank_events WHERE order_id='ORD-02'").fetchone()[0],1)
    def test_A02_banked_finish_hold_and_unauthorized_release(self):
        self.assertGreater(net(self.db,'ORD-01'),0)
        self.assertIn('Mandatory local technical approval pending',blockers(self.db,'ORD-01','production'))
        with self.assertRaises(ValueError):self.act('orders','ORD-01','release')
        with self.assertRaises(Forbidden):self.act('orders','ORD-01','exception',{'reason':'x','evidence':'x','impact':'x','gate':'production'},Actor('qazi','Sales'))
        self.act('approvals','APP-01','decide',{'evidence':'Local revision B signed','decision':'Approved'},Actor('rnd','R&D'))
        self.act('orders','ORD-01','release');self.assertEqual(record(self.db,'orders','ORD-01')['execution'],'Production')
    def test_A03_revision_and_approval_invalidation(self):
        original=record(self.db,'quotations','QUO-01')
        with self.assertRaises(ValueError):
            with transaction(self.db):save(self.db,self.actor,'quotations',{'version':original['version'],'total':'999'},'QUO-01')
        new=self.act('quotations','QUO-01','revise');q=record(self.db,'quotations',new)
        self.assertEqual(q['revision'],2);self.assertEqual(q['status'],'Draft');self.assertIsNone(q['accepted_at'])
        self.assertEqual(record(self.db,'quotations','QUO-01'),original)
        self.act('approvals','APP-01','decide',{'decision':'Approved','evidence':'signed'})
        with transaction(self.db):save(self.db,self.actor,'approvals',{'version':2,'item_revision':'C'},'APP-01')
        self.assertEqual(record(self.db,'approvals','APP-01')['decision'],'Pending')
    def test_A04_partial_award_split_delivery_adjustments_and_receipt_reversal(self):
        m=metrics(self.db,self.actor,{'account_id':'ACC-01'})
        self.assertGreaterEqual(m['pipeline'],6000000)
        self.assertNotEqual(record(self.db,'orders','ORD-06')['execution'],'Delivered')
        self.act('shipments','SHIP-02','deliver',{'evidence':'Signed proof for remaining 60'})
        self.assertEqual(record(self.db,'orders','ORD-06')['execution'],'Delivered')
        self.act('orders','ORD-01','adjust',{'amount':'-10000','kind':'Cancellation','reason':'Scope cancelled','evidence':'Signed variation','request_id':'adj-once'})
        self.act('orders','ORD-01','adjust',{'amount':'-10000','kind':'Cancellation','reason':'Scope cancelled','evidence':'Signed variation','request_id':'adj-once'})
        self.assertEqual(net(self.db,'ORD-01'),9000000)
        self.act('payments','PAY-01','reverse',{'reason':'Bank returned funds'})
        self.assertEqual(cash(self.db,'ORD-01'),0);self.assertIn('Verified advance is insufficient',blockers(self.db,'ORD-01','production'))
        self.assertEqual(self.db.execute("SELECT value FROM bank_events WHERE order_id='ORD-01'").fetchone()[0],10000000)
    def test_A05_calendar_timezone_and_ready_before_acknowledgment(self):
        cal={'day_basis':'working','timezone':'Asia/Karachi','workweek':'0,1,2,3,4','holidays':'2026-09-28'}
        self.assertEqual(eligible('2026-09-25T19:00:00+00:00','2026-09-29T19:00:00+00:00',cal),86400)
        dst={**cal,'timezone':'America/New_York','workweek':'0,1,2,3,4,5,6','holidays':''}
        self.assertEqual(eligible('2026-03-08T05:00:00+00:00','2026-03-09T04:00:00+00:00',dst),23*3600)
        m=record(self.db,'missions','MIS-2');self.assertTrue(m['ready_at']);self.assertIsNone(m['acknowledged_at'])
        self.act('opportunities','OPP-09','submit_enquiry')
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM enquiry_cycles WHERE opportunity_id='OPP-09'").fetchone()[0],1)
        self.act('opportunities','OPP-09','submit_enquiry')
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM enquiry_cycles WHERE opportunity_id='OPP-09'").fetchone()[0],1)
    def test_A06_hold_and_reassignment_preserve_original_clock(self):
        m=record(self.db,'missions','MIS-2');original=m['original_due'];ready=m['ready_at']
        self.db.execute("UPDATE missions SET ready_at='2026-09-21T00:00:00+00:00' WHERE id='MIS-2'")
        self.db.execute("UPDATE holds SET start_at='2026-09-22T00:00:00+00:00',end_at='2026-09-23T00:00:00+00:00' WHERE mission_id='MIS-2'")
        m=record(self.db,'missions','MIS-2');cal=json.loads(m['calendar_snapshot'])
        c=clock(self.db,m,'2026-09-24T00:00:00+00:00');self.assertEqual(c['elapsed'],eligible(m['ready_at'],'2026-09-24T00:00:00+00:00',cal)-86400)
        with transaction(self.db):save(self.db,self.actor,'missions',{'version':m['version'],'owner_id':'processor'},'MIS-2')
        updated=record(self.db,'missions','MIS-2');self.assertEqual(updated['original_due'],original);self.assertEqual(updated['ready_at'],m['ready_at'])
    def test_A07_submit_reject_accept_duplicate_and_reversal(self):
        self.act('missions','MIS-2','submit',{'evidence':'Revision A','checklist':'complete'},Actor('rnd','R&D'))
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM reward_ledger WHERE mission_id='MIS-2'").fetchone()[0],0)
        self.act('missions','MIS-2','reject',{'reason':'Finish reference missing'})
        self.assertEqual(self.db.execute("SELECT evidence FROM handoffs WHERE mission_id='MIS-2'").fetchone()[0],'Revision A')
        self.act('missions','MIS-2','submit',{'evidence':'Revision B','checklist':'complete'},Actor('rnd','R&D'))
        self.act('missions','MIS-2','accept');self.act('missions','MIS-2','accept')
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM reward_ledger WHERE mission_id='MIS-2'").fetchone()[0],1)
        self.act('missions','MIS-2','reverse_reward',{'reason':'Acceptance later withdrawn'})
        self.assertEqual(self.db.execute("SELECT SUM(points) FROM reward_ledger WHERE mission_id='MIS-2'").fetchone()[0],0)
    def test_A08_filtered_metrics_zero_and_overachievement(self):
        m=metrics(self.db,self.actor,{})
        self.assertEqual(m['net'],28000000);self.assertEqual(m['cash'],14000000);self.assertEqual(m['cash_rate'],.5);self.assertEqual(m['win_rate'],.5)
        self.assertEqual(metrics(self.db,self.actor,{'country':'Neverland'})['net'],0)
        self.assertIsNone(metrics(self.db,self.actor,{'country':'Neverland'})['achievement'])
        self.db.execute('UPDATE targets SET amount=10000000')
        m=metrics(self.db,self.actor,{});self.assertEqual(m['achievement'],2.8);self.assertEqual(m['gap'],0);self.assertIsNone(m['coverage'])
        self.assertAlmostEqual(metrics(self.db,self.actor,{'currency':'SAR'})['pipeline'],10000000,delta=1)
        with tempfile.TemporaryDirectory() as folder:
            app=create_app({'DATABASE':str(Path(folder)/'empty.db'),'UPLOAD_FOLDER':str(Path(folder)/'files'),'TESTING':True})
            db=connect(app.config['DATABASE']);self.assertEqual(db.execute('SELECT COUNT(*) FROM opportunities').fetchone()[0],0);db.close()
    def test_A09_rd_boundaries_ui_api_search_export_attachment_notifications(self):
        self.login('rnd','R&D')
        for url in ['/records/payments','/api/payments','/api/orders/ORD-01','/export/payments','/records/opportunities?q=100000','/download/PO-01','/reports','/overview','/admin']:
            with self.subTest(url=url):self.assertEqual(self.client.get(url).status_code,403)
        self.db.execute("UPDATE products SET owner_id='rnd' WHERE id='PROD-01'")
        for url in ['/api/products','/export/products','/api/missions']:
            response=self.client.get(url);self.assertEqual(response.status_code,200);self.assertNotIn('"cost"',response.get_data(as_text=True));self.assertNotIn('9000',response.get_data(as_text=True))
        self.assertIn('0 records',self.client.get('/records/products?q=9000').get_data(as_text=True))
        r=self.client.get('/my-day');self.assertEqual(r.status_code,200);self.assertNotIn('DEMO-RECEIPT',r.get_data(as_text=True))
    def test_A10_quick_create_import_conflict_restore(self):
        data={'title':'Quick enquiry','owner_id':'qazi','next_action':'Call buyer','due_date':date.today().isoformat(),'account_id':'ACC-01','country':'UAE','currency':'USD','source':'Phone','need':'Seating'}
        r=self.client.post('/api/opportunities',json=data);self.assertEqual(r.status_code,201,r.get_data(as_text=True));id=r.json['id']
        self.assertEqual(self.client.patch('/api/opportunities/'+id,json={'version':1,'next_action':'Send scope'}).status_code,200)
        self.assertEqual(self.client.patch('/api/opportunities/'+id,json={'version':1,'next_action':'Stale edit'}).status_code,409)
        bad='title,next_action,due_date,account_id,email\nA,Call,bad-date,ACC-01,a@example.test\nB,Call,2026-10-01,ACC-01,a@example.test'
        with transaction(self.db):result=preview(self.db,self.actor,'contacts',bad)
        self.assertTrue(result[0]['errors']);self.assertIn('Duplicate row in import',result[1]['errors'])
        target=sqlite3.connect(Path(self.tmp.name)/'restored.db');self.db.backup(target);self.assertEqual(target.execute('PRAGMA integrity_check').fetchone()[0],'ok');self.assertEqual(target.execute('SELECT COUNT(*) FROM opportunities').fetchone()[0],10);target.close()
    def test_all_screens_and_forms_render(self):
        for route in ['/overview','/my-day','/reports','/reports?kind=missing-actions','/admin','/records/opportunities?view=board']:
            with self.subTest(route=route):self.assertEqual(self.client.get(route).status_code,200)
        for table in MODULES:
            for route in [f'/records/{table}',f'/records/{table}/new']:
                with self.subTest(route=route):self.assertEqual(self.client.get(route).status_code,200)
            for r in self.db.execute(f'SELECT id FROM {table} LIMIT 1'):
                with self.subTest(table=table):self.assertEqual(self.client.get(f'/records/{table}/{r[0]}').status_code,200)
    def test_allocation_cannot_spend_receipt_twice(self):
        with self.assertRaises(ValueError):
            with transaction(self.db):save(self.db,self.actor,'payment_allocations',{'title':'Duplicate spend','next_action':'Review','due_date':date.today().isoformat(),'payment_id':'PAY-01','order_id':'ORD-01','amount':'1'})
    def test_notifications_are_idempotent(self):
        with transaction(self.db):automation(self.db)
        n=self.db.execute('SELECT COUNT(*) FROM notifications').fetchone()[0]
        with transaction(self.db):automation(self.db)
        self.assertEqual(self.db.execute('SELECT COUNT(*) FROM notifications').fetchone()[0],n)
    def test_audit_and_bank_events_are_immutable(self):
        with self.assertRaises(sqlite3.IntegrityError):self.db.execute('DELETE FROM audit_events')
        with self.assertRaises(sqlite3.IntegrityError):self.db.execute('UPDATE bank_events SET value=0')
    def test_auth_csrf_and_no_role_escalation(self):
        client=self.app.test_client();self.assertEqual(client.get('/api/orders').status_code,401)
        self.login('processor','Processor');self.assertEqual(self.client.post('/role',data={'role':'Administrator'}).status_code,403)
        self.app.config['TESTING']=False;self.assertEqual(self.client.post('/logout').status_code,400)
    def test_technical_user_cannot_remove_release_gate(self):
        with self.assertRaises(Forbidden):
            with transaction(self.db):save(self.db,Actor('rnd','R&D'),'approvals',{'version':1,'mandatory':0},'APP-01')
        self.assertEqual(record(self.db,'approvals','APP-01')['mandatory'],1)
    def test_retried_create_and_conversion_are_idempotent(self):
        self.act('quotations','QUO-03','accept',{'evidence':'Signed acceptance'})
        data={'amount':'40000','advance_required':'20000','request_id':'award-once'}
        first=self.act('quotations','QUO-03','convert_order',data);second=self.act('quotations','QUO-03','convert_order',data)
        self.assertEqual(first,second)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM orders WHERE opportunity_id='OPP-03'").fetchone()[0],1)
    def test_stage_cannot_skip_quotation_evidence(self):
        with self.assertRaises(ValueError):self.act('opportunities','OPP-09','stage',{'stage':'Negotiation'})
        self.assertEqual(record(self.db,'opportunities','OPP-09')['stage'],'Qualified')
    def test_reforecast_preserves_approved_commitment(self):
        original=record(self.db,'milestones','MILE-1')
        self.act('orders','ORD-01','reforecast')
        self.assertEqual(record(self.db,'milestones','MILE-1'),original)
        self.assertEqual(record(self.db,'orders','ORD-01')['risk_status'],'Blocked')
    def test_scope_change_preserves_original_and_ledger_snapshot(self):
        m=record(self.db,'missions','MIS-2')
        self.act('missions','MIS-2','scope_change',{'due_date':(date.today()+timedelta(days=10)).isoformat(),'reason':'Additional store scope','evidence':'Manager signed variation'})
        changed=record(self.db,'missions','MIS-2');self.assertEqual(changed['original_due'],m['original_due']);self.assertTrue(changed['approved_due']);self.assertEqual(changed['rule_snapshot'],m['rule_snapshot'])

if __name__=='__main__':unittest.main()
