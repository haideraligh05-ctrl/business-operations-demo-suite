"""Local entrypoint: python run.py init --demo; python run.py serve."""
import argparse, os, json, sqlite3, secrets, shutil
from pathlib import Path
from greenlight.app import create_app
from greenlight.db import connect, migrate, transaction, ROOT, now, audit
from greenlight.seed import seed

def main():
    parser=argparse.ArgumentParser(description='Commercial Workspace local workspace')
    parser.add_argument('command',choices=['init','serve','backup','restore','tick','create-user'])
    parser.add_argument('--demo',action='store_true');parser.add_argument('--database',default=str(ROOT/'instance/greenlight.db'));parser.add_argument('--port',type=int,default=5000);parser.add_argument('--path');parser.add_argument('--email');parser.add_argument('--name');parser.add_argument('--roles',default='Sales')
    args=parser.parse_args();dbpath=Path(args.database);dbpath.parent.mkdir(parents=True,exist_ok=True);uploads=dbpath.parent/'uploads'
    if args.command=='serve':
        app=create_app({'DATABASE':str(dbpath),'UPLOAD_FOLDER':str(uploads)});app.run(host='127.0.0.1',port=args.port,debug=False);return
    if args.command=='restore':
        if not args.path:parser.error('--path backup folder required')
        source=Path(args.path)/'greenlight.db'
        if dbpath.exists():raise SystemExit('Restore into a NEW database path to preserve existing data.')
        check=sqlite3.connect(f'file:{source.as_posix()}?mode=ro',uri=True)
        if check.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise SystemExit('Backup integrity check failed')
        target=sqlite3.connect(dbpath);check.backup(target);target.close();check.close()
        if (Path(args.path)/'uploads').exists():shutil.copytree(Path(args.path)/'uploads',uploads,dirs_exist_ok=True)
        print('Restored and verified:',dbpath);return
    db=connect(dbpath);migrate(db)
    if args.command=='init':
        if args.demo:
            with transaction(db):credentials=seed(db,uploads)
            text='# Local demonstration credentials\n\nGenerated for this local demo only. Do not use these accounts in production.\n\n'+ '\n'.join(f'- `{email}` / `{password}`' for email,password in credentials)+'\n'
            (ROOT/'DEMO_CREDENTIALS.md').write_text(text,encoding='utf-8');print('Demo initialized. Credentials saved to DEMO_CREDENTIALS.md')
        else:print('Empty schema initialized. Use create-user to provision the first account.')
    elif args.command=='create-user':
        from werkzeug.security import generate_password_hash
        from greenlight.models import ROLES
        from greenlight.db import uid,insert
        if not args.email or not args.name:parser.error('--email and --name required')
        roles=args.roles.split(',')
        if any(r not in ROLES for r in roles):parser.error('Invalid role')
        password=secrets.token_urlsafe(18);id=uid('USER')
        with transaction(db):
            insert(db,'users',dict(id=id,name=args.name,email=args.email,password_hash=generate_password_hash(password)))
            for role in roles:db.execute('INSERT INTO user_roles VALUES(?,?)',(id,role))
            audit(db,id,'Administrator','users',id,'local administrator provisioning',None,{'roles':roles})
        print('One-time local initial password:',password)
    elif args.command=='backup':
        if not args.path:parser.error('--path required')
        folder=Path(args.path)
        if folder.exists():raise SystemExit('Use a new backup folder')
        folder.mkdir(parents=True);dest=sqlite3.connect(folder/'greenlight.db');db.backup(dest);dest.close()
        if uploads.exists():shutil.copytree(uploads,folder/'uploads')
        (folder/'manifest.json').write_text(json.dumps({'created_at':now(),'schema':1,'includes':'database and protected uploads'}));print('Backup created:',folder)
    elif args.command=='tick':
        from greenlight.reporting import automation
        with transaction(db):automation(db)
        print('In-app reminders reconciled')
    db.close()

if __name__=='__main__':main()
