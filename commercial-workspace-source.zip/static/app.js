document.querySelector('.mobile-toggle')?.addEventListener('click',e=>{const open=document.body.classList.toggle('nav-open');e.currentTarget.setAttribute('aria-expanded',open)});
document.querySelectorAll('[data-explain]').forEach(button=>button.addEventListener('click',()=>{const panel=document.querySelector('.metric-detail');panel.hidden=false;panel.querySelector('p').textContent=button.dataset.explain;panel.querySelector('a').href=button.dataset.link;}));
document.querySelector('.close-detail')?.addEventListener('click',()=>document.querySelector('.metric-detail').hidden=true);
const tabs=[...document.querySelectorAll('[data-tab]')];
function activate(button){tabs.forEach(t=>{const on=t===button;t.setAttribute('aria-selected',on);t.tabIndex=on?0:-1;document.getElementById(t.dataset.tab).hidden=!on;});}
tabs.forEach((button,i)=>{button.tabIndex=i? -1:0;button.addEventListener('click',()=>activate(button));button.addEventListener('keydown',e=>{if(['ArrowRight','ArrowLeft','Home','End'].includes(e.key)){e.preventDefault();let next=e.key==='Home'?0:e.key==='End'?tabs.length-1:(i+(e.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;activate(tabs[next]);tabs[next].focus();}});});
